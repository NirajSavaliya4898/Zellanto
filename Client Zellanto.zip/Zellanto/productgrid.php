<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link rel="stylesheet" type="text/css" href="grid.css">
<section class="new-deal">
    <div class="container">
          <header>
            <h2 class="h3 heading-line">Camera Collection</h2>
          </header>
          <div class="col-lg-12">
              <div class="container">
                <?php 
                  include("connection.php");
                  $qry="select * from camera c,media m,brand b where c.media_id=m.media_id and c.brand_id=b.brand_id  order by cam_id Desc limit 6";
                  $result=mysqli_query($con,$qry);
                  while($lst=mysqli_fetch_array($result))
                  {
                                
                ?>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 deal deal-block">
                    <div class="item-slide">
                        <div class="box-img">
                          <img style="height: 300px !important;width: 250px !important;"src="../admin/media/<?php echo $lst['media_url']; ?>" alt="media"/>
                          <div class="text-wrap">
                            <h4><?php echo $lst['name']."-".$lst['cam_name']; ?> <span class="deal-data"></h4>
                            <div class="desc">
                              <h3>₹<?php echo $lst['bodyprice']."-".$lst['bodywithlenseprice']; ?></h3>
                            </div>
                            <div class="book-now-c">                
                              <a href="#">Book Now</a>
                            </div>
                          </div>
                        </div>
                        <div class="slide-hover">
                          <div class="text-wrap">
                          <p><?php echo $lst['description1']."<br/>".$lst['description2']; ?>  <span class="deal-data"></h4>
                            <div class="desc">                  
                              <span></span>
                              <h3>₹<?php echo $lst['bodyprice']."-".$lst['bodywithlenseprice']; ?></h3>
                            </div>
                            <div class="book-now-c">
                              <a href="#">Book Now</a>
                            </div>
                          </div>
                        </div>
                    </div>
              </div>
              <?php
              }
              ?>    
            </div>
          </div>
    </div>
</section>