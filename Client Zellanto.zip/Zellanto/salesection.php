<section class="sale">
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <h2>Discover 2019 Sales</h2>
              <p>lorem ipsum dolor sit amet consectetur adipiscing elit, ed do eiusmod tempor incididunt</p><a href="#" class="btn btn-dark shop-now">Shop Now</a>
            </div>
            <div class="col-md-6 d-none d-md-block">
              <div class="product"><img src="./img/nikon-cam.png" alt="camera" class="img-fluid"></div>
            </div>
          </div>
        </div>
</section>