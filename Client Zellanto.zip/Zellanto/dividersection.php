 <section class="divider">
        <div class="container text-center">
          <p class="h5">New Arrival Collections</p>
          <h2>For your perfect photos</h2>
          <hr>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.</p><a href="#" class="btn btn-white">Learn More</a>
        </div>
</section>