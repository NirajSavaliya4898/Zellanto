<?php
session_start();
$con=mysqli_connect("localhost","root","") or die("Could not connect");
mysqli_select_db($con,"clients") or die("Could not select db");

$qry="select * from user where user_name='".$_POST['username']."' and password='".$_POST['pass']."'";
echo $qry;
$result=mysqli_query($con,$qry);


if(mysqli_num_rows($result)>0)
{
	
	$_SESSION["uname"] = $_POST["username"];
	header("location:index.php");
}
else
{
	header("location:login.php");
}
?>