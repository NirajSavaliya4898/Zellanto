<?php
//Start your session.
session_start();
?>
<!DOCTYPE html>
<html>
  
<!-- Mirrored from demo.bootstrapious.com/photo/1-4/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jan 2019 12:10:37 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Zellanto</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="./vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="./vendor/font-awesome/css/font-awesome.min.css">
    <!-- Font icons-->
    <link rel="stylesheet" href="./css/custom-icons.css">
    <!-- Google fonts - Roboto for copy, Playfair Display for headings-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,700">
    <!-- Owl Carousel-->
    <link rel="stylesheet" href="./vendor/owl.carousel/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="./vendor/owl.carousel/assets/owl.theme.default.min.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="./css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="./css/custom.css">
    <!-- zellanto-->
    <link rel="shortcut icon" href="img/z.png">
        <link href="https://raw.githubusercontent.com/daneden/animate.css/master/animate.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="slidecss.css">
        <!-- login -->
        <link rel="stylesheet" type="text/css" href="logincss.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
        <link rel="stylesheet" type="text/css" href="camera.css">
  </head>
  <body>
    <!-- Top Bar -->
    <?php include("topbar.php");?>
    <!-- Navbar -->
    <?php include("navbar.php");?>
    <div class="home-page">
      <!-- Hero Section-->
      <?php include("herosection.php");?>
      <!-- Categories Section-->
      <?php include("categorysection.php");?>
      <!-- Cameras Section-->
      <?php include("camerasection.php");?>
      <!-- Sale Section-->
      <?php include("salesection.php");?>
      <!-- Lenses Section-->
      <?php include("lencesection.php");?>
      <!-- Divider Section-->
      <?php include("dividersection.php");?>
      <!-- Newsletter Section-->
      <?php include("newlattersection.php");?>
    </div>
    <!-- Search Panel-->
    <?php include("searchpanel.php");?>
    <!-- Footer-->
    <?php include("footer.php");?>
    <!-- JavaScript files-->
    <script src="./vendor/jquery/jquery.min.js"></script>
    <script src="./vendor/popper.js/umd/popper.min.js"> </script>
    <script src="./vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="./vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="./vendor/owl.carousel/owl.carousel.min.js"></script>
    <script src="./vendor/owl.carousel2.thumbs/owl.carousel2.thumbs.min.js"></script>
    <script src="./vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="./js/front.js"></script>
    <script>$('#myCarousel').carousel({
    interval: 5000
    })</script>
  </body>

<!-- Mirrored from demo.bootstrapious.com/photo/1-4/<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud</p.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jan 2019 12:10:38 GMT -->
</html>