<?php 
include("connection.php");

session_start();

$_SESSION['cart'] = "";
$_SESSION['cart']['product_id'] = "";
$_SESSION['cart']['product_detail'] = "";

echo "<pre>";
print_r($_SESSION['cart'])

?>