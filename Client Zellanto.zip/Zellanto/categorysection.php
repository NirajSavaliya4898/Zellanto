<section class="categories">
        <div class="container">
          <div class="categories-inner">
            <header>
              <h2 class="h5 heading-line d-none d-md-block">Categories</h2>
            </header>
            <div class="row text-center">
              <?php
                    include("connection.php");
                    $qry="select * from category";
                    $result=mysqli_query($con,$qry);
                    while($lst=mysqli_fetch_array($result))
                    {
                    
                    ?>
                  <div class="col-md-4 item"><a href="<?php echo $lst['cat_name']; ?>.php">
                    <h4><?php echo $lst['cat_name']; ?></h4>
                    <p><?php echo $lst['description']; ?></p>
                    <div class="image"><img src="../Admin/image/<?php echo $lst['media_url']; ?>" alt="" class="img-fluid"></div></a>
                  </div>
                <?php 
                }
                ?>
          </div>
        </div>
      </section>