<!DOCTYPE html>
<html>
  
<!-- Mirrored from demo.bootstrapious.com/photo/1-4/cart.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jan 2019 12:10:43 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Zellanto</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="./vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="./vendor/font-awesome/css/font-awesome.min.css">
    <!-- Font icons-->
    <link rel="stylesheet" href="./css/custom-icons.css">
    <!-- Google fonts - Roboto for copy, Playfair Display for headings-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,700">
    <!-- Owl Carousel-->
    <link rel="stylesheet" href="./vendor/owl.carousel/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="./vendor/owl.carousel/assets/owl.theme.default.min.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="./css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="./css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/z.png">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  </head>
  <body>
    <!-- Top Bar -->
    <?php include("topbar.php");?>
    <!-- Navbar -->
    <?php include("navbar.php");?>
    <div class="cart-page">
      <!-- Breadcrumb -->
      <div class="container">
        <ol class="breadcrumb">
          <li class="breadcrumb-item text-uppercase"> <a href="index.php" class="text-primary">Home</a></li>
          <li class="breadcrumb-item text-uppercase"> <a href="cart.php" class="text-primary">Cart</a></li>
          <li class="breadcrumb-item text-uppercase"> <a href="invoice.php" class="text-primary">Invoice</a></li>
          <li class="breadcrumb-item active text-uppercase">Payment</li>
        </ol>
      </div>
      <div class="payment-method">
                <h3 class="heading-line">Payment Method</h3>
                <div class="row">
                  <div class="col-sm-6 form-group">
                    <input type="text" name="cardname" placeholder="Name On Card" required="" class="form-control">
                  </div>
                  <div class="col-sm-6 form-group">
                    <input type="text" name="cardnumber" placeholder="Card Number" maxlength="14" required="" class="form-control">
                  </div>
                  <div class="col-sm-4 form-group">
                    <input type="text" name="expirymonth" placeholder="Expiry Month" required="" class="form-control">
                  </div>
                  <div class="col-sm-4 form-group">
                    <input type="text" name="expiryyear" placeholder="Expiry Year" required="" class="form-control">
                  </div>
                  <div class="col-sm-4 form-group">
                    <input type="text" name="cvv" placeholder="CVV" maxlength="3" required="" class="form-control">
                  </div>
                  <div class="col-sm-12 text-center">
                    <button id="shipping-submit" type="submit" class="oder-now btn btn-unique btn-lg">Order Now <i class="icon-shipping-truck"></i></button>
                  </div>
                </section>
                </div>
      </div>
    <!-- Search Panel-->
    <div class="search-overlay">
      <div class="search-inner d-flex justify-content-center align-items-center">
        <div class="search-close"><i class="icon-close"></i></div>
        <div class="container">
          <div class="form-holder">
            <form class="d-flex">
              <input type="search" placeholder="What are you looking for...">
              <button type="submit" class="search text-primary text-uppercase">Search</button>
            </form>
          </div>
        </div>
      </div>
    </div>
    <!-- Footer-->
    <?php include("footer.php");?>
    <!-- JavaScript files-->
    <script src="./vendor/jquery/jquery.min.js"></script>
    <script src="./vendor/popper.js/umd/popper.min.js"> </script>
    <script src="./vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="./vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="./vendor/owl.carousel/owl.carousel.min.js"></script>
    <script src="./vendor/owl.carousel2.thumbs/owl.carousel2.thumbs.min.js"></script>
    <script src="./vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="./js/front.js"></script>
  </body>

<!-- Mirrored from demo.bootstrapious.com/photo/1-4/cart.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jan 2019 12:10:43 GMT -->
</html>