<section class="product-1">
        <div class="container">
          <header>
            <h2 class="h3 heading-line">Cameras Collection</h2>
          </header>
          <div class="row d-flex flex-row align-items-stretch">
            <!-- <div class="col-lg-6">
              <div class="item item-big text-right">
                <h2>EOS R </h2>
                <h3>(RF24-105mm f/4L IS USM)</h3></h2>
                <div class="row">
                    <div class=""><h4 class="title">Warranty :- </h4></div>
                    <div class=""><h4>2 Years</h4></div>
                </div>
                <div class="row">
                  <div class=""><h4 class="title">Body Price :- </h4></div>
                  <div class=""><h4>₹ 174990.00</h4></div>
                </div>
                <div class="row">
                  <div class=""><h4 class="title">Body + Lense Price :- </h4></div>
                  <div class=""><h4>₹ 256990.00</h4></div>
                </div>
                <a href="category.php" class="btn btn-unique btn-lg">Shop Now</a><img src="img/EOS R.png" alt="camera" class="img-fluid">
              </div>
            </div> -->
            <div class="col-lg-12">
              <div class="row">
                <?php 
                  include("connection.php");
                  $qry="select * from camera c,media m,brand b where c.media_id=m.media_id and c.brand_id=b.brand_id  order by cam_id Desc limit 6";
                  $result=mysqli_query($con,$qry);
                  while($lst=mysqli_fetch_array($result))
                  {
                                
                ?>
                <div class="col-md-4">
                  <div class="item">
                    <div class="product-grid5">
                      <div class="product-image5">
                            <a href="#">
                                <img class="pic-2 img-thumbnail" src="../admin/media/<?php echo $lst['media_url']; ?>">
                                <!-- <img class="pic-2" src="http://bestjquery.com/tutorial/product-grid/demo11/images/img-2.jpg"> -->
                            </a>
                            <ul class="social">
                                <li><a href="" data-tip="Quick View"><i class="fa fa-search"></i></a></li>
                                <li><a href="" data-tip="Add to Wishlist"><i class="fa fa-shopping-bag"></i></a></li>
                                <li><a href="" data-tip="Add to Cart"><i class="fa fa-shopping-cart"></i></a></li>
                            </ul>
                            <a href="viewcamera.php?cid=<?php echo $lst['cam_id']; ?>" class="select-options"><i class="fa fa-arrow-right"></i> View Camera... </a>
                        </div><br/>
                      </div>
                      <h4><?php echo $lst['name']."-".$lst['cam_name']; ?></h4>
                      <p class="text-primary">₹ <?php echo $lst['bodyprice']."-".$lst['bodywithlenseprice']; ?></p>
                  </div>
                </div>
                <?php }?>
              </div>
            </div>
          </div>
        </div>
      </section>