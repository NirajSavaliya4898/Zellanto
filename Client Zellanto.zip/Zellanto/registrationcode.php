<?php
    $con=mysqli_connect("localhost","root","") or die("Could not connect");
    mysqli_select_db($con,"clients") or die("Could not select db");

$user=$_POST['username'];
$mail=$_POST['email'];
$pass=$_POST['password'];
if(!(empty($user) && empty($email) && empty($pass)))
{
	$qry="insert into user(user_name,email,password)
		values('$user','$mail','$pass')";	
}
else
{
	header("location:index.php?error=1");
	exit;
}

		echo $qry;
if(mysqli_query($con,$qry))
{
	header("location:index.php");
}
else
{
	echo mysqli_error($con);
}
?>