<!DOCTYPE html>
<html>
  
<!-- Mirrored from demo.bootstrapious.com/photo/1-4/cart.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jan 2019 12:10:43 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Zellanto</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="./vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="./vendor/font-awesome/css/font-awesome.min.css">
    <!-- Font icons-->
    <link rel="stylesheet" href="./css/custom-icons.css">
    <!-- Google fonts - Roboto for copy, Playfair Display for headings-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,700">
    <!-- Owl Carousel-->
    <link rel="stylesheet" href="./vendor/owl.carousel/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="./vendor/owl.carousel/assets/owl.theme.default.min.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="./css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="./css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/z.png">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  </head>
  <body>
    <!-- Top Bar -->
    <?php include("topbar.php");?>
    <!-- Navbar -->
    <?php include("navbar.php");?>
    <div class="cart-page">
      <!-- Breadcrumb -->
      <div class="container">
        <ol class="breadcrumb">
          <li class="breadcrumb-item text-uppercase"> <a href="index.php" class="text-primary">Home</a></li>
          <li class="breadcrumb-item active text-uppercase">Shopping Cart</li>
        </ol>
      </div>
      <!-- Shopping Cart Section-->
      <section class="cart">
        <div class="container">
          <div class="cart-holder">
            <div class="shipping-main">
                <h3 class="heading-line">Shopping Cart</h3>
                <?php if(isset($_REQUEST['error']) == 1): ?>
                    <div class="alert alert-danger">Please fill the required fields.</div>
                    <?php endif; ?>
            <div class="cart-heading text-center">
              <div class="row">
                <div class="col-5 text-left">Product</div>
                <div class="col-2">Price</div>
                <div class="col-2">Quantity</div>
                <div class="col-2">Total</div>
                <div class="col-1"></div>
              </div>
            </div>
            <div class="cart-body text-center">
              <div class="row cart-item">
                <div class="col-5">
                  <div class="product-overview text-left d-flex"><a href="detail.php" class="product-img"><img src="./img/cart-item.jpg" alt="product" class="img-fluid"></a>
                    <div class="product-details"><a href="detail.php">
                        <h3 class="h4">Fast telephoto zoom lense nano crystal</h3></a></div>
                  </div>
                </div>
                <div class="col-2"><strong>$500</strong></div>
                <div class="col-2">
                  <div class="product-quantity d-flex align-items-center justify-content-center">
                    <div class="minus-btn"><i class="icon-android-remove"></i></div>
                    <input type="text" value="1" class="quantity">
                    <div class="plus-btn"><i class="icon-android-add"></i></div>
                  </div>
                </div>
                <div class="col-2"><strong>$500</strong></div>
                <div class="col-1"><a href="#"><img src='img/delete_png.png' height='20px' width='20px'></i></a></div>
              </div>
              <!-- <div class="row cart-item">
                <div class="col-5">
                  <div class="product-overview text-left d-flex"><a href="detail.php" class="product-img"><img src="./img/cart-item.jpg" alt="product" class="img-fluid"></a>
                    <div class="product-details"><a href="detail.php">
                        <h3 class="h4">Fast telephoto zoom lense nano crystal</h3></a></div>
                  </div>
                </div>
                <div class="col-2"><strong>$500</strong></div>
                <div class="col-2">
                  <div class="product-quantity d-flex align-items-center justify-content-center">
                    <div class="minus-btn"><i class="icon-android-remove"></i></div>
                    <input type="text" value="1" class="quantity">
                    <div class="plus-btn"><i class="icon-android-add"></i></div>
                  </div>
                </div>
                <div class="col-2"><strong>$500</strong></div>
                <div class="col-1"><a href="#"><img src='img/delete_png.png' height='20px' width='20px'></i></a></div>
              </div>
            </div>
          </div> -->
          <div class="total-price text-right">
            <div class="container">
              <div class="d-flex justify-content-end align-items-center"><span class="h3">Total: &nbsp;</span><strong class="h2 text-primary">$500</strong></div>
            </div>
          </div>
          </div>
        </div>
      </section><br/>
      <div align="center">
            <a href='index.php' id="shipping-submit" class="oder-now btn btn-unique btn-lg">Continue Shopping</a>
            <a href='invoice.php' id="shipping-submit" class="oder-now btn btn-unique btn-lg">Place Order</a>
      </div>
    </div>
    <!-- Search Panel-->
    <div class="search-overlay">
      <div class="search-inner d-flex justify-content-center align-items-center">
        <div class="search-close"><i class="icon-close"></i></div>
        <div class="container">
          <div class="form-holder">
            <form class="d-flex">
              <input type="search" placeholder="What are you looking for...">
              <button type="submit" class="search text-primary text-uppercase">Search</button>
            </form>
          </div>
        </div>
      </div>
    </div>
    <!-- Footer-->
    <?php include("footer.php");?>
    <!-- JavaScript files-->
    <script src="./vendor/jquery/jquery.min.js"></script>
    <script src="./vendor/popper.js/umd/popper.min.js"> </script>
    <script src="./vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="./vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="./vendor/owl.carousel/owl.carousel.min.js"></script>
    <script src="./vendor/owl.carousel2.thumbs/owl.carousel2.thumbs.min.js"></script>
    <script src="./vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="./js/front.js"></script>
  </body>

<!-- Mirrored from demo.bootstrapious.com/photo/1-4/cart.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jan 2019 12:10:43 GMT -->
</html>