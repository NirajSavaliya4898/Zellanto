<!DOCTYPE html>
<html>
  
<!-- Mirrored from demo.bootstrapious.com/photo/1-4/detail.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jan 2019 12:10:40 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Photo - Bootstrap 4 E-commerce Template</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="./vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="./vendor/font-awesome/css/font-awesome.min.css">
    <!-- Font icons-->
    <link rel="stylesheet" href="./css/custom-icons.css">
    <!-- Google fonts - Roboto for copy, Playfair Display for headings-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,700">
    <!-- Owl Carousel-->
    <link rel="stylesheet" href="./vendor/owl.carousel/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="./vendor/owl.carousel/assets/owl.theme.default.min.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="./css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="./css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/z.png">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  </head>
  <body>
    <!-- Top Bar -->
    <?php include("topbar.php");?>
    <!-- Navbar -->
    <?php include("navbar.php");?>
    <div class="details-page">
      <!-- Breadcrumb -->
      <div class="container">
        <ol class="breadcrumb">
          <li class="breadcrumb-item text-uppercase"> <a href="index.php" class="text-primary">Home</a></li>
          <li class="breadcrumb-item text-uppercase"> <a href="category.php" class="text-primary">Lenses</a></li>
          <li class="breadcrumb-item active text-uppercase">Fast telephoto zoom lense</li>
        </ol>
      </div>
      <!-- Item details -->
      <section class="item-details p-t-small p-b-small">
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <div data-slider-id="1" class="owl-carousel item-slider">
                <div class="item"> <img src="./img/detail-2.jpg" alt="lens"></div>
                <div class="item"> <img src="./img/detail-1.jpg" alt="lens"></div>
                <div class="item"> <img src="./img/detail-3.jpg" alt="lens"></div>
                <div class="item"> <img src="./img/detail-4.jpg" alt="lens"></div>
              </div>
              <div data-slider-id="1" class="owl-thumbs">
                <button class="owl-thumb-item"><img src="./img/detail-2-small.jpg" alt="lens"></button>
                <button class="owl-thumb-item"><img src="./img/detail-1-small.jpg" alt="lens"></button>
                <button class="owl-thumb-item"><img src="./img/detail-3-small.jpg" alt="lens"></button>
                <button class="owl-thumb-item"><img src="./img/detail-4-small.jpg" alt="lens"></button>
              </div>
              <div class="brief">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore eligendi, hic illo, debitis similique maxime molestias voluptates sunt. Natus asperiores, unde dolorem nemo reprehenderit totam consequatur eos. Ipsa, voluptatibus, laborum.</p>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore eligendi, hic illo, debitis similique maxime molestias voluptates sunt. Natus asperiores, unde dolorem nemo reprehenderit totam consequatur eos. Ipsa, voluptatibus, laborum.</p>
              </div>
            </div>
            <div class="col-md-6">
              <h1 class="h2">Fast Telephoto Zoom Lens Nano Crystal</h1>
              <div class="price d-flex justify-content-between align-items-center text-primary">$599.00
                <div class="d-flex justify-content-center">
                  <ul class="rate list-inline">
                    <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                    <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                    <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                    <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                    <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                  </ul><span>No Reviews</span>
                </div>
              </div>
              <div class="model">
                <ul class="list-unstyled">
                  <li><span class="text-uppercase">Item No: </span>AF-S NiKKOR 70-200mm f/2.8G ED</li>
                  <li><span class="text-uppercase">Category: </span>Zoom Lenses</li>
                  <li><span class="text-uppercase">Availability: </span>In Stock</li>
                </ul>
              </div>
              <div class="description">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
              </div>
              <form action="#" method="get">
                <div class="row d-flex justify-content-between">
                  <div class="col-lg-6">
                    <ul class="product-quantity list-inline">
                      <li class="list-inline-item"> 
                        <h3 class="h5">Quantity</h3>
                      </li>
                      <li class="list-inline-item"> 
                        <div class="counter d-flex align-items-center justify-content-start">
                          <div class="minus-btn"><i class="icon-android-remove"></i></div>
                          <input type="text" value="1" class="quantity">
                          <div class="plus-btn"><i class="icon-android-add"></i></div>
                        </div>
                      </li>
                    </ul>
                  </div>
                  <div class="col-lg-6">
                    <select name="variant" title="variant" class="country form-control">
                      <option value="">D750 body only</option>
                      <option value="">24-120mm VR Lens Kit</option>
                    </select>
                  </div>
                </div>
                <div class="CTAs"> 
                  <ul class="list-inline">
                    <li class="list-inline-item">
                      <button href="#" class="btn btn-unique">Add To Cart</button>
                    </li>
                    <li class="list-inline-item"><a href="#" class="btn btn-dark">Add to wishlist<i class="fa fa-heart"></i></a></li>
                  </ul>
                </div>
              </form>
              <div class="specifications">
                <ul class="property list-unstyled">
                  <li class="title">Focal Length</li>
                  <li class="value">70-200mm</li>
                </ul>
                <ul class="property list-unstyled">
                  <li class="title">Maximum Apparature</li>
                  <li class="value">F/2.8</li>
                </ul>
                <ul class="property list-unstyled">
                  <li class="title">Minimum Apparature</li>
                  <li class="value">F/22</li>
                </ul>
                <ul class="property list-unstyled">
                  <li class="title">Lens Construction</li>
                  <li class="value">21 element in 16 groups (with 7 ED and some Nano Crystal lens elements)</li>
                </ul>
                <ul class="property list-unstyled">
                  <li class="title">Weight</li>
                  <li class="value">Approximately 1.540 g/3.4 lb</li>
                </ul>
                <ul class="property list-unstyled">
                  <li class="title">Filter/Attachment size</li>
                  <li class="value">77mm</li>
                </ul>
                <ul class="property list-unstyled">
                  <li class="title">Maimum Reproduction Ratio</li>
                  <li class="value">.12x</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- Related Items                         -->
      <section class="related-items p-t-small p-b-small">
        <div class="container">
          <h3 class="heading-line">You May Also Like</h3>
          <div class="row">
                <div class="col-lg-3 col-md-6">
                  <div class="item text-center">
                    <div class="product-image"><img src="./img/detail-related-1.jpg" alt="camera">
                      <div class="overlay"> <a href="#" class="wishlist"><i class="fa fa-heart"></i></a>
                        <ul class="list-unstyled">
                          <li><a href="#" class="btn btn-unique">View Detail</a></li>
                          <li><a href="#" class="btn btn-dark">Add To Cart</a></li>
                        </ul>
                      </div>
                    </div><a href="#" class="item-name">
                      <h4>EOS 7D Mark II EF-S 18 135mm</h4></a>
                    <ul class="list-inline rate text-primary">
                      <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                      <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                      <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                      <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                      <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                    </ul>
                    <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci, ut, voluptas possimus magnam.</p>
                    <ul class="price list-inline">
                      <li class="list-inline-item"> <span class="price">$1.299</span></li>
                    </ul>
                  </div>
                </div>
                <div class="col-lg-3 col-md-6">
                  <div class="item text-center">
                    <div class="product-image"><span class="new badge badge-pill badge-info text-uppercase">new</span><img src="./img/detail-related-2.jpg" alt="camera">
                      <div class="overlay"> <a href="#" class="wishlist"><i class="fa fa-heart"></i></a>
                        <ul class="list-unstyled">
                          <li><a href="#" class="btn btn-unique">View Detail</a></li>
                          <li><a href="#" class="btn btn-dark">Add To Cart</a></li>
                        </ul>
                      </div>
                    </div><a href="#" class="item-name">
                      <h4>EOS 7D Mark II EF-S 18 135mm</h4></a>
                    <ul class="list-inline rate text-primary">
                      <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                      <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                      <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                      <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                      <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                    </ul>
                    <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci, ut, voluptas possimus magnam.</p>
                    <ul class="price list-inline">
                      <li class="list-inline-item"> <span class="price">$1.299</span></li>
                    </ul>
                  </div>
                </div>
                <div class="col-lg-3 col-md-6">
                  <div class="item text-center">
                    <div class="product-image"><img src="./img/detail-related-3.jpg" alt="camera">
                      <div class="overlay"> <a href="#" class="wishlist"><i class="fa fa-heart"></i></a>
                        <ul class="list-unstyled">
                          <li><a href="#" class="btn btn-unique">View Detail</a></li>
                          <li><a href="#" class="btn btn-dark">Add To Cart</a></li>
                        </ul>
                      </div>
                    </div><a href="#" class="item-name">
                      <h4>EOS 7D Mark II EF-S 18 135mm</h4></a>
                    <ul class="list-inline rate text-primary">
                      <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                      <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                      <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                      <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                      <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                    </ul>
                    <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci, ut, voluptas possimus magnam.</p>
                    <ul class="price list-inline">
                      <li class="list-inline-item"> <span class="price">$1.299</span></li>
                    </ul>
                  </div>
                </div>
                <div class="col-lg-3 col-md-6">
                  <div class="item text-center">
                    <div class="product-image"><img src="./img/detail-related-3.jpg" alt="camera">
                      <div class="overlay"> <a href="#" class="wishlist"><i class="fa fa-heart"></i></a>
                        <ul class="list-unstyled">
                          <li><a href="#" class="btn btn-unique">View Detail</a></li>
                          <li><a href="#" class="btn btn-dark">Add To Cart</a></li>
                        </ul>
                      </div>
                    </div><a href="#" class="item-name">
                      <h4>EOS 7D Mark II EF-S 18 135mm</h4></a>
                    <ul class="list-inline rate text-primary">
                      <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                      <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                      <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                      <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                      <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                    </ul>
                    <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci, ut, voluptas possimus magnam.</p>
                    <ul class="price list-inline">
                      <li class="list-inline-item"> <span class="price">$1.299</span></li>
                    </ul>
                  </div>
                </div>
          </div>
        </div>
      </section>
    </div>
    <!-- Search Panel-->
    <?php include("searchpanel.php");?>
    <!-- Footer-->
    <?php include("footer.php");?>
    <!-- JavaScript files-->
    <script src="./vendor/jquery/jquery.min.js"></script>
    <script src="./vendor/popper.js/umd/popper.min.js"> </script>
    <script src="./vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="./vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="./vendor/owl.carousel/owl.carousel.min.js"></script>
    <script src="./vendor/owl.carousel2.thumbs/owl.carousel2.thumbs.min.js"></script>
    <script src="./vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="./js/front.js"></script>
  </body>

<!-- Mirrored from demo.bootstrapious.com/photo/1-4/detail.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jan 2019 12:10:43 GMT -->
</html>