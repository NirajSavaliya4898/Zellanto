<!DOCTYPE html>
<html>
<head>
<title></title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!--jQuery(necessary for Bootstrap's JavaScript plugins)-->
<script src="js/jquery-1.11.0.min.js"></script>
<!--Custom-Theme-files-->
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Luxury Watches Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />

<link rel="stylesheet" href="./vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="./vendor/font-awesome/css/font-awesome.min.css">
    <!-- Font icons-->
    <link rel="stylesheet" href="./css/custom-icons.css">
    <!-- Google fonts - Roboto for copy, Playfair Display for headings-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,700">
    <!-- Owl Carousel-->
    <link rel="stylesheet" href="./vendor/owl.carousel/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="./vendor/owl.carousel/assets/owl.theme.default.min.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="./css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="./css/custom.css">
    <!-- zellanto-->
    <link rel="shortcut icon" href="img/z.png">
        <link href="https://raw.githubusercontent.com/daneden/animate.css/master/animate.css" rel="stylesheet">     
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
     

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--start-menu-->
<script src="js/simpleCart.min.js"> </script>
<link href="css/memenu.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="js/memenu.js"></script>
<script>$(document).ready(function(){$(".memenu").memenu();});</script>	
<!--dropdown-->
<script src="js/jquery.easydropdown.js"></script>	
<script type="text/javascript">
	$(function() {
	
	    var menu_ul = $('.menu_drop > li > ul'),
	           menu_a  = $('.menu_drop > li > a');
	    
	    menu_ul.hide();
	
	    menu_a.click(function(e) {
	        e.preventDefault();
	        if(!$(this).hasClass('active')) {
	            menu_a.removeClass('active');
	            menu_ul.filter(':visible').slideUp('normal');
	            $(this).addClass('active').next().stop(true,true).slideDown('normal');
	        } else {
	            $(this).removeClass('active');
	            $(this).next().stop(true,true).slideUp('normal');
	        }
	    });
	
	});
</script>		
</head>
<body> 

	<?php include('topbar.php'); ?>
	<?php include('navbar.php'); ?>
	<div class="category-page">
		<div class="container">
	        <ol class="breadcrumb">
	          <li class="breadcrumb-item text-uppercase"><a href="index.php" class="text-primary">Home</a></li>
	          <li class="breadcrumb-item active text-uppercase"><a href="camera.php" class="text-primary">Camera</a></li>
	          <li class="breadcrumb-item active text-uppercase">View Camera...</li>
	        </ol>
	      </div>
	<?php
	include("connection.php");
	$qry="select * from camera c,media m,brand b where c.media_id=m.media_id and c.brand_id=b.brand_id  and cam_id=".$_REQUEST['cid'];
	$result=mysqli_query($con,$qry);
	$lst=mysqli_fetch_array($result);
	?>
	<div class="single contact">
		<div class="container">
			<div class="single-main">
				<div class="col-md-9 single-main-left">
				<div class="sngl-top">
					<div class="col-md-5 single-top-left">	
						<div class="flexslider">
							  <ul class="slides">
								<li data-thumb="../admin/media/<?php echo $lst['cam_id']; ?>">
									<div class="thumb-image"><img style="height: 300px !important;width: 250px !important;" src="../admin/media/<?php echo $lst['media_url']; ?>" data-imagezoom="true" class="img-responsive" alt=""/> </div>
								</li>
								<!-- <li data-thumb="images/s-2.jpg">
									 <div class="thumb-image"> <img src="images/s-2.jpg" data-imagezoom="true" class="img-responsive" alt=""/> </div>
								</li>
								<li data-thumb="images/s-3.jpg">
								   <div class="thumb-image"> <img src="images/s-3.jpg" data-imagezoom="true" class="img-responsive" alt=""/> </div>
								</li> --> 
							  </ul>
						</div>
						<!-- FlexSlider -->
						<script src="js/imagezoom.js"></script>
						<script defer src="js/jquery.flexslider.js"></script>
						<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />

						<script>
						// Can also be used with $(document).ready()
						$(window).load(function() {
						  $('.flexslider').flexslider({
							animation: "slide",
							controlNav: "thumbnails"
						  });
						});
						</script>
					</div>	
					<div class="col-md-7 single-top-right">
						<div class="single-para simpleCart_shelfItem">
						<h2><?php echo $lst['name']."-".$lst['cam_name']; ?></h2>
							<div class="star-on">
								<ul class="star-footer">
										<li><a href="#"><i> </i></a></li>
										<li><a href="#"><i> </i></a></li>
										<li><a href="#"><i> </i></a></li>
										<li><a href="#"><i> </i></a></li>
										<li><a href="#"><i> </i></a></li>
									</ul>
								<div class="review">
									<a href="#"> 1 customer review </a>
									
								</div>
								<div class="clearfix"> </div>
							</div>
							<h5 class="item_price">₹ <?php echo $lst['bodyprice']."-".$lst['bodywithlenseprice']; ?></h5>
							<p><?php echo $lst['description1']."<br/>".$lst['description2']."<br/>".$lst['description3']; ?></p><br/>
							<ul class="tag-men">
								<div class="row">
	                                <div class=""><h3 class="title">Warranty :- </h3></div>
	                                <div class=""><h4 class="subitem2"><?php echo $lst['warranty']; ?>Years</h4></div>
	                            </div>
								<div class="row">
	                                <div class=""><h3 class="title">Body Price :- </h3></div>
	                                <div class=""><h4 class="title">₹<?php echo $lst['bodyprice']; ?></h4></div>
	                            </div>
	                            <div class="row">
	                                <div class=""><h3 class="title">Body + Lense Price :- </h3></div>
	                                <div class=""><h4 class="title">₹<?php echo $lst['bodywithlenseprice']; ?></h4></div>
	                            </div>
							</ul>
								<a href="#" class="add-cart item_add">ADD TO CART</a>
						</div>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="tabs">
					<ul class="menu_drop">
				<li class="item1"><a href="#"><img src="images/arrow.png" alt="">Description</a>
					<ul>
						<li class="subitem1"><a href="#"><?php echo $lst['description1']; ?></a></li>
						<li class="subitem2"><a href="#"><?php echo $lst['description2']; ?></a></li>
						<li class="subitem3"><a href="#"><?php echo $lst['description3']; ?></a></li>
					</ul>
				</li>
				<li class="item2"><a href="#"><img src="images/arrow.png" alt="">Additional information</a>
					<ul>
						<li class="subitem1"><a href="#"><?php echo $lst['description1']; ?></a></li>
						<li class="subitem2"><a href="#"><?php echo $lst['description2']; ?></a></li>
						<li class="subitem3"><a href="#"><?php echo $lst['description3']; ?></a></li>
					</ul>
				</li>
				<li class="item3"><a href="#"><img src="images/arrow.png" alt="">Reviews (10)</a>
					<ul>
						<ul>
						<li class="subitem1"><a href="#"><?php echo $lst['description1']; ?></a></li>
						<li class="subitem2"><a href="#"><?php echo $lst['description2']; ?></a></li>
						<li class="subitem3"><a href="#"><?php echo $lst['description3']; ?></a></li>
					</ul>
					</ul>
				</li>
				<li class="item4"><a href="#"><img src="images/arrow.png" alt="">Helpful Links</a>
					<ul>
					    <li class="subitem1"><a href="#"> https://in.canon/en/consumer/products/search?category=photography&subCategory=interchangeable-lens-cameras</a></li>
						
					</ul>
				</li>
				<li class="item5"><a href="#"><img src="images/arrow.png" alt="">Make A Gift</a>
					<ul>
						<li class="subitem1"><a href="#">Motorola Pulse Escape Wireless Over-Ear Headphones</a></li>
					</ul>
				</li>
	 		</ul>
				</div>
			</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>