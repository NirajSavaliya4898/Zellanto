<div id="myCarousel" class="carousel slide carousel-fade" data-ride="carousel">
  <div class="carousel-inner">
    <?php
        include("connection.php");
        $qry="SELECT 
              s.title,s.sub_title,s.btn_text,s.btn_url,m.media_url 
              FROM slider s,media m 
              WHERE s.media_id=m.media_id 
              LIMIT 3";
        $result=mysqli_query($con,$qry);
        $i = 1;
        while($lst=mysqli_fetch_array($result))
        {
      ?>
    <div class="carousel-item <?php if($i == 1){ ?> active <?php } ?>">
      <div class="mask flex-center">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-md-7 col-12 order-md-2 order-5">
              <h5><?php echo $lst['title']; ?></h5>
              <h5><?php echo $lst['sub_title']; ?></h5><br/>
              <a target="_blank" title="view more" href="<?php echo $lst['btn_url']; ?>"><?php echo $lst['btn_text']; ?></a> 
           </div>
            <div class="col-md-5 col-12 order-md-2 order-1"><img src="../Admin/media/<?php echo $lst['media_url']; ?>" class="mx-auto" alt="slide"></div>
          </div>
        </div>
      </div>
    </div>
    <?php $i++; } ?>
    <!-- <div class="carousel-item">
      <div class="mask flex-center">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-md-7 col-12 order-md-1 order-2">
              <h5>EF70-200mm<br>
               f/2.8L IS III USM</h4><br/>
               <a href="#">VIEW MORE</a>
                <a href="#">BUY NOW</a> </div>
            <div class="col-md-5 col-12 order-md-2 order-1"><img style="height: 400px !important;width: 200px !important;" src="img/lense.png" class="mx-auto" alt="slide"></div>
          </div>
        </div>
      </div>
    </div>
    <div class="carousel-item">
      <div class="mask flex-center">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-md-7 col-12 order-md-1 order-2">
              <h4>Sonia Potra Light<br>
              for Video and Continuous Lighting</h4><br/>
              <a href="#">VIEW MORE</a>
              <a href="#">BUY NOW</a> </div>
            <div class="col-md-5 col-12 order-md-2 order-1"><img src="img/potra.jpg" height="800px"
            width="800px" class="mx-auto" alt="slide"></div>
          </div>
        </div>
      </div>
    </div>
  </div> -->
</div>
  <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev"> <span class="carousel-control-prev-icon" aria-hidden="true"></span> <span class="sr-only">Previous</span> </a> <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next"> <span class="carousel-control-next-icon" aria-hidden="true"></span> <span class="sr-only">Next</span> </a> 
  </div>