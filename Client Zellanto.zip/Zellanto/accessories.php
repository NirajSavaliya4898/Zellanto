<!DOCTYPE html>
<html>
  
<!-- Mirrored from demo.bootstrapious.com/photo/1-4/category.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jan 2019 12:10:40 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Zellanto</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="./vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="./vendor/font-awesome/css/font-awesome.min.css">
    <!-- Font icons-->
    <link rel="stylesheet" href="./css/custom-icons.css">
    <!-- Google fonts - Roboto for copy, Playfair Display for headings-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,700">
    <!-- Owl Carousel-->
    <link rel="stylesheet" href="./vendor/owl.carousel/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="./vendor/owl.carousel/assets/owl.theme.default.min.css">
    <!-- NoUI Slider-->
    <link rel="stylesheet" href="./vendor/nouislider/nouislider.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="./css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="./css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/z.png">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <!------ Include the above in your HEAD tag ---------->

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
        <link rel="stylesheet" type="text/css" href="camera.css">
  </head>
  <body>
    <!-- Top Bar -->
    <?php include("topbar.php");?>
    <!-- Navbar -->
    <?php include("navbar.php");?>
    <div class="category-page">
      <!-- Breadcrumb -->
      <div class="container">
        <ol class="breadcrumb">
          <li class="breadcrumb-item text-uppercase"> <a href="index.php" class="text-primary">Home</a></li>
          <li class="breadcrumb-item active text-uppercase">Accessories</li>
        </ol>
      </div>
      <!-- Products-->
      <div class="container">
    <h1 class="heading-line">Accessories</h1>
    <div class="row">
        <?php
        $con=mysqli_connect("localhost","root","") or die("Could not connect");
        mysqli_select_db($con,"zellanto") or die("Could not select db");
        $qry="select * from accessories a,media m,brand b,accessoriesmaster am where a.media_id=m.media_id and a.brand_id=b.brand_id and a.Acc_cat_id=am.acc_cat_id order by Acc_id Desc";
        $result=mysqli_query($con,$qry);
        while($lst=mysqli_fetch_array($result))
        {
        ?>
        <div class="col-md-3 col-sm-5">
            <div class="product-grid5">
                <div class="product-image5">
                            <a href="#">
                                <img style="height: 300px !important;width: 250px !important;" class="pic-2 img-thumbnail" src="../admin/media/<?php echo $lst['media_url']; ?>">
                                <!-- <img class="pic-2" src="http://bestjquery.com/tutorial/product-grid/demo11/images/img-2.jpg"> -->
                            </a>
                            <ul class="social">
                                <li><a href="" data-tip="Quick View"><i class="fa fa-search"></i></a></li>
                                <li><a href="" data-tip="Add to Wishlist"><i class="fa fa-shopping-bag"></i></a></li>
                                <li><a href="" data-tip="Add to Cart"><i class="fa fa-shopping-cart"></i></a></li>
                            </ul>
                            <a href="viewaccessories.php?aid=<?php echo $lst['Acc_id']; ?>" class="select-options"><i class="fa fa-arrow-right"></i> View Accessories... </a>
                        </div>
                        <div class="product-content">
                            <h2 class="title"><a href="#"><?php echo $lst['name']."-".$lst['acc_name']; ?></a></h2>
                            <div class="row">
                                <div class=""><h3 class="title">Product Type :- </h3></div>
                                <div class="Warranty"><?php echo $lst['acc_cat']; ?></div>
                            </div>
                           <div class="row">
                                <div class=""><h3 class="title">Warranty :- </h3></div>
                                <div class="Warranty"><?php echo $lst['warranty']; ?>Years</div>
                            </div>
                             <div class="row">
                                <div class=""><h3 class="title">Price :- </h3></div>
                                <div class=""><?php echo $lst['price']; ?></div>
                            </div>
                        </div><br/>
                        </div>
                </div>
            <?php 
            }
            ?>
    </div>
</div>
<hr>
    </div>
    <!-- Search Panel-->
    <?php include("searchpanel.php");?>
    <!-- Footer-->
    <?php include("footer.php");?>
    <!-- JavaScript files-->
    <script src="./vendor/jquery/jquery.min.js"></script>
    <script src="./vendor/popper.js/umd/popper.min.js"> </script>
    <script src="./vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="./vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="./vendor/owl.carousel/owl.carousel.min.js"></script>
    <script src="./vendor/owl.carousel2.thumbs/owl.carousel2.thumbs.min.js"></script>
    <script src="./vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="./js/front.js"></script>
    <script src="./vendor/nouislider/nouislider.min.js"></script>
    <script>
      // var snapSlider = document.getElementById('slider-snap');
      
      // noUiSlider.create(snapSlider, {
      //   start: [ 40, 110 ],
      //   snap: false,
      //   connect: true,
      //     step: 1,
      //   range: {
      //     'min': 0,
      //     'max': 250
      //   }
      // });
      var snapValues = [
        document.getElementById('slider-snap-value-lower'),
        document.getElementById('slider-snap-value-upper')
      ];
      // snapSlider.noUiSlider.on('update', function( values, handle ) {
      //   snapValues[handle].innerHTML = values[handle];
      // });
  </script>
  </body>

<!-- Mirrored from demo.bootstrapious.com/photo/1-4/category.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jan 2019 12:10:40 GMT -->
</html>