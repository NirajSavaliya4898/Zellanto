<nav class="navbar navbar-expand-lg px-lg-0">
      <div class="container position-relative">
        <!-- Navbar Brand-->
        <a href="index.php" class="navbar-brand"> <img src="./img/zeel.png" alt="logo"></a>
        <!-- Toggle Button-->
        <button type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler navbar-toggler-right">Menu <i class="fa fa-bars"></i></button>
        <!-- Navbar Menu-->
        <div id="navbarSupportedContent" class="collapse navbar-collapse">
          <div class="navbar-nav ml-auto align-items-lg-center">
            <div class="nav-item dropdown">
              <a id="navbarHome" data-target="#" href="index.php" class="nav-link nav-ba">Home<i class="fa fa-caret"></i></a></div>
                <div class="nav-item dropdown">
                  <a id="navbarCategory" data-target="#" href="index.php" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link">Category<i class="fa fa-caret-down"></i></a>
                    <div aria-labelledby="navbarCategory" class="dropdown-menu">
                      <a href="camera.php" class="dropdown-item">Cameras</a>
                      <a href="lenses.php" class="dropdown-item">Lenses</a>
                      <a href="accessories.php" class="dropdown-item">Accessories</a></div>
                    </div>
            <!-- Megamenu-->
            <div class="nav-item"><a href="#" data-toggle="dropdown" class="nav-link">Template content<i class="fa fa-caret-down"></i></a>
              <div class="dropdown-menu megamenu">
                <div class="row">
                  <div class="col-lg-4 d-none d-lg-block">
                    <!-- <div style="background: center center url('./img/hero-bg-1.jpg') no-repeat;" class="w-100 h-100"></div> -->
                  </div>
                  <div class="col-lg-8">
                    <div class="row px-lg-3 py-lg-5">
                      <div class="col-lg-4">
                            <!-- Megamenu list-->
                            <h6 class="heading-line">Homepage</h6>
                            <ul class="megamenu-list list-unstyled">
                              <li class="megamenu-list-item"><a href="index.php" class="megamenu-list-link">Homepage  </a></li>
                            </ul>
                            <!-- Megamenu list-->
                            <h6 class="heading-line">Shop</h6>
                            <ul class="megamenu-list list-unstyled">
                              <li class="megamenu-list-item"><a href="camera.php" class="megamenu-list-link">Cameras   </a></li>
                              <li class="megamenu-list-item"><a href="lenses.php" class="megamenu-list-link">Lenses   </a></li>
                              <li class="megamenu-list-item"><a href="accessories.php" class="megamenu-list-link">Accessories   </a></li>
                            </ul>
                      </div>
                      <div class="col-lg-4">
                            <!-- Megamenu list-->
                            <h6 class="heading-line">Order process</h6>
                            <ul class="megamenu-list list-unstyled">
                              <li class="megamenu-list-item"><a href="cart.php" class="megamenu-list-link">Shopping cart + checkout   </a></li>
                            </ul>
                            <!-- Megamenu list-->
                            <h6 class="heading-line">Blog</h6>
                            <ul class="megamenu-list list-unstyled">
                              <li class="megamenu-list-item"><a href="blog.php" class="megamenu-list-link">Blog   </a></li>
                              <li class="megamenu-list-item"><a href="post.php" class="megamenu-list-link">Post   </a></li>
                              <li class="megamenu-list-item"><a href="ourteam.php" class="megamenu-list-link">Our Team   </a></li>
                            </ul>
                            <!-- Megamenu list-->
                            <h6 class="heading-line">Pages</h6>
                            <ul class="megamenu-list list-unstyled">
                              <li class="megamenu-list-item"><a href="text.php" class="megamenu-list-link">Text page   </a></li>
                              <li class="megamenu-list-item"><a href="contact.php" class="megamenu-list-link">Contact   </a></li>
                            </ul>
                      </div>
                      <div class="col-lg-4">
                            <!-- Megamenu list-->
                            <h6 class="heading-line">Some more links</h6>
                            <ul class="megamenu-list list-unstyled">
                              <li class="megamenu-list-item"><a href="#" class="megamenu-list-link">Lorem   </a></li>
                              <li class="megamenu-list-item"><a href="##" class="megamenu-list-link">Ipsum dolor   </a></li>
                              <li class="megamenu-list-item"><a href="###" class="megamenu-list-link">Sit amet   </a></li>
                              <li class="megamenu-list-item"><a href="####" class="megamenu-list-link">Lorem   </a></li>
                              <li class="megamenu-list-item"><a href="#####" class="megamenu-list-link">Ipsum dolor   </a></li>
                              <li class="megamenu-list-item"><a href="######" class="megamenu-list-link">Sit amet   </a></li>
                            </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- /Megamenu end    -->
            <!-- Multi level dropdown    -->
            <div class="nav-item dropdown"><a id="navbarDropdownMenuLink" href="http://example.com/" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link">Dropdown<i class="fa fa-caret-down"></i></a>
              <div aria-labelledby="navbarDropdownMenuLink" class="dropdown-menu"><a href="#" class="dropdown-item">Action</a><a href="#" class="dropdown-item">Another action</a>
                <div class="dropdown-submenu"><a id="navbarDropdownMenuLink2" href="http://example.com/" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-item">Multilevel dropdown<i class="fa fa-caret-down"></i></a>
                  <div aria-labelledby="navbarDropdownMenuLink2" class="dropdown-menu"><a href="#" class="dropdown-item">Action</a>
                    <div class="dropdown-submenu"><a id="navbarDropdownMenuLink3" href="http://example.com/" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-item">
                         
                        Another action<i class="fa fa-caret-down"></i></a>
                      <div aria-labelledby="navbarDropdownMenuLink3" class="dropdown-menu"><a href="#" class="dropdown-item">Action</a><a href="#" class="dropdown-item">Action</a><a href="#" class="dropdown-item">Action</a><a href="#" class="dropdown-item">Action</a></div>
                    </div><a href="#" class="dropdown-item">Something else here</a>
                  </div>
                </div>
              </div>
            </div>
            <!-- Multi level dropdown end      -->
            <div class="nav-item"><a href="contact.php" class="nav-link">Contact Us</a></div>
            <div class="nav-item">
              <ul class="list-inline">
                <li class="list-inline-item"><a id="search" href="#" class="nav-link">
                    <div class="icon search"><i class="icon-magnifying-glass"></i></div></a></li>
                <li class="list-inline-item"><a href="cart.php" class="nav-link">
                    <div class="icon cart"><i class="icon-cart"></i></div><span class="d-md-none d-lg-inline"><span class="no">2</span>items</span></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </nav>

