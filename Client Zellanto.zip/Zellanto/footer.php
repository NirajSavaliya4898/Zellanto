<footer class="main-footer">
      <div class="page-links">
        <div class="container">
          <div class="row">
            <div class="col-lg-3 col-sm-6">
              <h3>Site Map</h3>
              <ul class="list-unstyled">
                <li> <a href="index.php">Home</a></li>
                <li> <a href="#">About Us</a></li>
                <li> <a href="#">Categories</a></li>
                <li> <a href="#">Privacy policy</a></li>
                <li> <a href="contact.php">Contact Us</a></li>
              </ul>
            </div>
            <div class="col-lg-3 col-sm-6">
              <h3>Information</h3>
              <ul class="list-unstyled">
                <li> <a href="#">Specials</a></li>
                <li> <a href="#">New Products</a></li>
                <li> <a href="#">Our Stores</a></li>
                <li> <a href="#">Contact Us</a></li>
                <li> <a href="#">Top Sellers</a></li>
              </ul>
            </div>
            <div class="col-lg-2 col-sm-6">
              <h3>My Account</h3>
              <ul class="list-unstyled">
                <li> <a href="login.php">Login Account</a></li>
                <li> <a href="#">My Credit slips</a></li>
                <li> <a href="#">My Merchandise returns</a></li>
                <li> <a href="#">My Personal info</a></li>
                <li> <a href="#">My Addresses</a></li>
              </ul>
            </div>
            <div class="col-lg-4 col-sm-6 details js-pull">
              <ul class="list-unstyled">
                <li class="d-flex align-items-center">
                  <div class="icon"><i class="icon-delivery-truck"></i></div>
                  <div class="text"> 
                    <h3>Free Shipping Worldwide</h3>
                    <p>On orders over $200</p>
                  </div>
                </li>
                <li class="d-flex align-items-center">
                  <div class="icon"><i class="icon-dollar-symbol"></i></div>
                  <div class="text"> 
                    <h3>30 days money back</h3>
                    <p>Money back guarantee</p>
                  </div>
                </li>
                <li class="d-flex align-items-center">
                  <div class="icon"><i class="icon-phone-call"></i></div>
                  <div class="text"> 
                    <h3>Phone: 75677-16693</h3>
                    <p>Contact with us</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="copyrights">
        <div class="container">
          <div class="row">
            <div class="col-sm-6">
              <p>&copy; 2019 <span class="text-primary">Zellanto.com.  </span>All rights reserved.</p>
            </div>
            <div class="col-sm-6 text-right">
              <p>Power by <a href="https://Zellanto/" target="_blank">Zeel</a></p>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!-- JavaScript files-->
    <script src="./vendor/jquery/jquery.min.js"></script>
    <script src="./vendor/popper.js/umd/popper.min.js"> </script>
    <script src="./vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="./vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="./vendor/owl.carousel/owl.carousel.min.js"></script>
    <script src="./vendor/owl.carousel2.thumbs/owl.carousel2.thumbs.min.js"></script>
    <script src="./vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="./js/front.js"></script>
    
