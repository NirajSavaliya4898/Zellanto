<!DOCTYPE html>
<html>
  
<!-- Mirrored from demo.bootstrapious.com/photo/1-4/category.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jan 2019 12:10:40 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Zellanto</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="./vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="./vendor/font-awesome/css/font-awesome.min.css">
    <!-- Font icons-->
    <link rel="stylesheet" href="./css/custom-icons.css">
    <!-- Google fonts - Roboto for copy, Playfair Display for headings-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,700">
    <!-- Owl Carousel-->
    <link rel="stylesheet" href="./vendor/owl.carousel/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="./vendor/owl.carousel/assets/owl.theme.default.min.css">
    <!-- NoUI Slider-->
    <link rel="stylesheet" href="./vendor/nouislider/nouislider.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="./css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="./css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/z.png">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  </head>
  <body>
    <!-- Top Bar -->
    <?php include("topbar.php");?>
    <!-- Navbar -->
    <?php include("navbar.php");?>
    <div class="category-page">
      <!-- Breadcrumb -->
      <div class="container">
        <ol class="breadcrumb">
          <li class="breadcrumb-item text-uppercase"> <a href="index.php" class="text-primary">Home</a></li>
          <li class="breadcrumb-item active text-uppercase">Cameras</li>
        </ol>
      </div>
      <!-- Products-->
      <section class="products p-t-small">
        <div class="container">
          <header class="mb-5">
            <h1 class="heading-line">Cameras</h1>
            <p class="lead">Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo. </p>
          </header>
          <div class="row">
            <div class="col-lg-9 order-lg-2">
              <div class="row">
                    <div class="col-lg-4 col-sm-6">
                      <div class="item text-center">
                        <div class="product-image"><img src="./img/product-1.jpg" alt="camera">
                          <div class="overlay"> <a href="#" class="wishlist"><i class="fa fa-heart"></i></a>
                            <ul class="list-unstyled">
                              <li><a href="detail.php" class="btn btn-unique">View Detail</a></li>
                              <li><a href="#" class="btn btn-dark">Add To Cart</a></li>
                            </ul>
                          </div>
                        </div><a href="detail.php" class="item-name">
                          <h4>EOS 7D Mark II EF-S 18 135mm</h4></a>
                        <ul class="list-inline rate text-primary">
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                        </ul>
                        <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci, ut, voluptas possimus magnam.</p>
                        <ul class="price list-inline">
                          <li class="list-inline-item"> <span class="price">$1,299</span></li>
                        </ul>
                      </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                      <div class="item text-center">
                        <div class="product-image"><span class="new badge badge-pill badge-info text-uppercase">new</span><img src="./img/product-2.jpg" alt="camera">
                          <div class="overlay"> <a href="#" class="wishlist"><i class="fa fa-heart"></i></a>
                            <ul class="list-unstyled">
                              <li><a href="detail.php" class="btn btn-unique">View Detail</a></li>
                              <li><a href="#" class="btn btn-dark">Add To Cart</a></li>
                            </ul>
                          </div>
                        </div><a href="detail.php" class="item-name">
                          <h4>EOS 7D Mark II EF-S 18 135mm</h4></a>
                        <ul class="list-inline rate text-primary">
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                        </ul>
                        <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci, ut, voluptas possimus magnam.</p>
                        <ul class="price list-inline">
                          <li class="list-inline-item"> <span class="price">$1,299</span></li>
                        </ul>
                      </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                      <div class="item text-center">
                        <div class="product-image"><img src="./img/product-3.jpg" alt="camera">
                          <div class="overlay"> <a href="#" class="wishlist"><i class="fa fa-heart"></i></a>
                            <ul class="list-unstyled">
                              <li><a href="detail.php" class="btn btn-unique">View Detail</a></li>
                              <li><a href="#" class="btn btn-dark">Add To Cart</a></li>
                            </ul>
                          </div>
                        </div><a href="detail.php" class="item-name">
                          <h4>EOS 7D Mark II EF-S 18 135mm</h4></a>
                        <ul class="list-inline rate text-primary">
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                        </ul>
                        <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci, ut, voluptas possimus magnam.</p>
                        <ul class="price list-inline">
                          <li class="list-inline-item"> <span class="price">$1,299</span></li>
                        </ul>
                      </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                      <div class="item text-center">
                        <div class="product-image"><span class="sale badge badge-pill badge-primary text-uppercase">sale</span><img src="./img/product-4.jpg" alt="camera">
                          <div class="overlay"> <a href="#" class="wishlist"><i class="fa fa-heart"></i></a>
                            <ul class="list-unstyled">
                              <li><a href="detail.php" class="btn btn-unique">View Detail</a></li>
                              <li><a href="#" class="btn btn-dark">Add To Cart</a></li>
                            </ul>
                          </div>
                        </div><a href="detail.php" class="item-name">
                          <h4>EOS 7D Mark II EF-S 18 135mm</h4></a>
                        <ul class="list-inline rate text-primary">
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                        </ul>
                        <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci, ut, voluptas possimus magnam.</p>
                        <ul class="price list-inline">
                          <li class="list-inline-item"> <span class="price-old">$1,299</span></li>
                          <li class="list-inline-item"> <span class="price-new">$700</span></li>
                        </ul>
                      </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                      <div class="item text-center">
                        <div class="product-image"><img src="./img/product-5.jpg" alt="camera">
                          <div class="overlay"> <a href="#" class="wishlist"><i class="fa fa-heart"></i></a>
                            <ul class="list-unstyled">
                              <li><a href="detail.php" class="btn btn-unique">View Detail</a></li>
                              <li><a href="#" class="btn btn-dark">Add To Cart</a></li>
                            </ul>
                          </div>
                        </div><a href="detail.php" class="item-name">
                          <h4>EOS 7D Mark II EF-S 18 135mm</h4></a>
                        <ul class="list-inline rate text-primary">
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                        </ul>
                        <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci, ut, voluptas possimus magnam.</p>
                        <ul class="price list-inline">
                          <li class="list-inline-item"> <span class="price">$1,299</span></li>
                        </ul>
                      </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                      <div class="item text-center">
                        <div class="product-image"><img src="./img/product-6.jpg" alt="camera">
                          <div class="overlay"> <a href="#" class="wishlist"><i class="fa fa-heart"></i></a>
                            <ul class="list-unstyled">
                              <li><a href="detail.php" class="btn btn-unique">View Detail</a></li>
                              <li><a href="#" class="btn btn-dark">Add To Cart</a></li>
                            </ul>
                          </div>
                        </div><a href="detail.php" class="item-name">
                          <h4>EOS 7D Mark II EF-S 18 135mm</h4></a>
                        <ul class="list-inline rate text-primary">
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                        </ul>
                        <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci, ut, voluptas possimus magnam.</p>
                        <ul class="price list-inline">
                          <li class="list-inline-item"> <span class="price">$1,299</span></li>
                        </ul>
                      </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                      <div class="item text-center">
                        <div class="product-image"><img src="./img/product-7.jpg" alt="camera">
                          <div class="overlay"> <a href="#" class="wishlist"><i class="fa fa-heart"></i></a>
                            <ul class="list-unstyled">
                              <li><a href="detail.php" class="btn btn-unique">View Detail</a></li>
                              <li><a href="#" class="btn btn-dark">Add To Cart</a></li>
                            </ul>
                          </div>
                        </div><a href="detail.php" class="item-name">
                          <h4>EOS 7D Mark II EF-S 18 135mm</h4></a>
                        <ul class="list-inline rate text-primary">
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                        </ul>
                        <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci, ut, voluptas possimus magnam.</p>
                        <ul class="price list-inline">
                          <li class="list-inline-item"> <span class="price">$1,299</span></li>
                        </ul>
                      </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                      <div class="item text-center">
                        <div class="product-image"><img src="./img/product-2.jpg" alt="camera">
                          <div class="overlay"> <a href="#" class="wishlist"><i class="fa fa-heart"></i></a>
                            <ul class="list-unstyled">
                              <li><a href="detail.php" class="btn btn-unique">View Detail</a></li>
                              <li><a href="#" class="btn btn-dark">Add To Cart</a></li>
                            </ul>
                          </div>
                        </div><a href="detail.php" class="item-name">
                          <h4>EOS 7D Mark II EF-S 18 135mm</h4></a>
                        <ul class="list-inline rate text-primary">
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                        </ul>
                        <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci, ut, voluptas possimus magnam.</p>
                        <ul class="price list-inline">
                          <li class="list-inline-item"> <span class="price">$1,299</span></li>
                        </ul>
                      </div>
                    </div>
              </div>
              <!-- Pagination -->
              <div class="pagination pagination-custom mt-5">
                <nav aria-label="...">
                  <ul class="pagination pagination-sm d-flex justify-content-between">
                    <li class="page-item disabled"><a href="#" tabindex="-1" class="page-link">Previous</a></li>
                    <li> 
                      <ul class="pages list-inline">
                        <li class="page-item active list-inline-item"><a href="#" class="page-link">1</a></li>
                        <li class="page-item list-inline-item"><a href="#" class="page-link">2</a></li>
                        <li class="page-item list-inline-item"><a href="#" class="page-link">3</a></li>
                      </ul>
                    </li>
                    <li class="page-item"><a href="#" class="page-link">Next</a></li>
                  </ul>
                </nav>
              </div>
            </div>
            <div class="col-lg-3 order-lg-1">
              <!-- Sidebar-->
              <div class="sidebar mt-5 mt-lg-0 mr-lg-4">
                <div class="sidebar-block px-3 px-lg-0 undefined">
                  <h5 class="heading-line mb-4"> Categories</h5>
                  <div class="nav nav-pills flex-column sidebar-nav"><a href="#" class="nav-link d-flex justify-content-between mb-1 "><span>Cameras</span><span class="badge badge-light"> 120</span></a>
                    <div class="nav nav-pills flex-column ml-3"><a href="#" class="nav-link mb-1">Lorem ipsum</a><a href="#" class="nav-link mb-1">Dolor</a><a href="#" class="nav-link mb-1">Sit amet</a><a href="#" class="nav-link mb-1">Donec vitae</a>
                    </div><a href="#" class="nav-link d-flex justify-content-between mb-1 active"><span>Lenses</span><span class="badge badge-light"> 55</span></a>
                    <div class="nav nav-pills flex-column ml-3"><a href="#" class="nav-link mb-1">Lorem ipsum</a><a href="#" class="nav-link mb-1">Dolor</a><a href="#" class="nav-link mb-1">Sit amet</a><a href="#" class="nav-link mb-1">Donec vitae</a>
                    </div><a href="#" class="nav-link d-flex justify-content-between mb-1 "><span>Accessories</span><span class="badge badge-light"> 80</span></a>
                    <div class="nav nav-pills flex-column ml-3"><a href="#" class="nav-link mb-1">Sit amet</a><a href="#" class="nav-link mb-1">Donec vitae</a><a href="#" class="nav-link mb-1">Lorem ipsum</a><a href="#" class="nav-link mb-1">Dolor</a>
                    </div>
                  </div>
                </div>
                <div class="sidebar-block px-3 px-lg-0 undefined">
                  <h5 class="heading-line mb-5"> Price  </h5>
                  <div id="slider-snap" class="mt-4"></div>
                  <div class="nouislider-values">
                    <div class="min">From $<span id="slider-snap-value-lower"></span></div>
                    <div class="max">To $<span id="slider-snap-value-upper"></span></div>
                  </div>
                </div>
                <div class="sidebar-block px-3 px-lg-0 undefined">
                  <h5 class="heading-line mb-4">Brand </h5>
                  <form action="#">
                    <div class="form-group mb-1">
                      <div class="custom-control custom-checkbox">
                        <input id="brand0" type="checkbox" name="clothes-brand" checked class="custom-control-input">
                        <label for="brand0" class="custom-control-label">Canon <small>(18)</small></label>
                      </div>
                    </div>
                    <div class="form-group mb-1">
                      <div class="custom-control custom-checkbox">
                        <input id="brand1" type="checkbox" name="clothes-brand" checked class="custom-control-input">
                        <label for="brand1" class="custom-control-label">Nikon <small>(30)</small></label>
                      </div>
                    </div>
                    <div class="form-group mb-1">
                      <div class="custom-control custom-checkbox">
                        <input id="brand2" type="checkbox" name="clothes-brand" class="custom-control-input">
                        <label for="brand2" class="custom-control-label">Sony <small>(120)</small></label>
                      </div>
                    </div>
                    <div class="form-group mb-1">
                      <div class="custom-control custom-checkbox">
                        <input id="brand3" type="checkbox" name="clothes-brand" class="custom-control-input">
                        <label for="brand3" class="custom-control-label">Olympus <small>(70)</small></label>
                      </div>
                    </div>
                    <div class="form-group mb-1">
                      <div class="custom-control custom-checkbox">
                        <input id="brand4" type="checkbox" name="clothes-brand" class="custom-control-input">
                        <label for="brand4" class="custom-control-label">Leika  <small>(110)</small></label>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
              <!-- /Sidebar end-->
            </div>
          </div>
        </div>
      </section>
    </div>
    <!-- Search Panel-->
    <?php include("searchpanel.php");?>
    <!-- Footer-->
    <!-- JavaScript files-->
    <script src="./vendor/jquery/jquery.min.js"></script>
    <script src="./vendor/popper.js/umd/popper.min.js"> </script>
    <script src="./vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="./vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="./vendor/owl.carousel/owl.carousel.min.js"></script>
    <script src="./vendor/owl.carousel2.thumbs/owl.carousel2.thumbs.min.js"></script>
    <script src="./vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="./js/front.js"></script>
    <script src="./vendor/nouislider/nouislider.min.js"></script>
    <script>
      var snapSlider = document.getElementById('slider-snap');
      
      noUiSlider.create(snapSlider, {
        start: [ 40, 110 ],
        snap: false,
        connect: true,
          step: 1,
        range: {
          'min': 0,
          'max': 250
        }
      });
      var snapValues = [
        document.getElementById('slider-snap-value-lower'),
        document.getElementById('slider-snap-value-upper')
      ];
      snapSlider.noUiSlider.on('update', function( values, handle ) {
        snapValues[handle].innerHTML = values[handle];
      });
                  
      
      
    </script>
  </body>

<!-- Mirrored from demo.bootstrapious.com/photo/1-4/category.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jan 2019 12:10:40 GMT -->
</html>