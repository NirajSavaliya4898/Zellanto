<?php
$con=mysqli_connect("localhost","root","") or die("Could not connect");
mysqli_select_db($con,"zellanto") or die("Could not select db");
$name=$_GET['firstname'].$_GET['lastname'];
$add=$_GET['address-2'].$_GET['address-1'].$_GET['city'].$_GET['postalcode'];
$cont=$_GET['number'];
$dob=$_GET['dob'];
$gen=$_GET['gender'];
$email=$_GET['email'];
$pass=$_GET['password'];
if(!(empty($name) && empty($address) && empty($contect) && empty($dob) && empty($email) && empty($pass)))
{
	$qry="insert into customer(name,address,contect,dob,gender,email,password)
		values('$name','$add','$cont','$dob','$gen','$email','$pass')";	
}
else
{
	header("location:invoice.php?error=1");
	exit;
}

		echo $qry;
if(mysqli_query($con,$qry))
{
	header("location:payment.php");
}
else
{
	echo mysqli_error($con);
}
?>