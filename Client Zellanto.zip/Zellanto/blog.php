<!DOCTYPE html>
<html>
  
<!-- Mirrored from demo.bootstrapious.com/photo/1-4/blog.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jan 2019 12:10:43 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Photo - Bootstrap 4 E-commerce Template</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="./vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="./vendor/font-awesome/css/font-awesome.min.css">
    <!-- Font icons-->
    <link rel="stylesheet" href="./css/custom-icons.css">
    <!-- Google fonts - Roboto for copy, Playfair Display for headings-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,700">
    <!-- Owl Carousel-->
    <link rel="stylesheet" href="./vendor/owl.carousel/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="./vendor/owl.carousel/assets/owl.theme.default.min.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="./css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="./css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="favicon.png">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  </head>
  <body>
    <!-- Top Bar -->
    <?php include("topbar.php");?>
    <!-- Navbar -->
    <?php include("navbar.php");?>
    <!-- Breadcrumb -->
    <div class="container">
      <ol class="breadcrumb">
        <li class="breadcrumb-item text-uppercase"> <a href="index.php" class="text-primary">Home</a></li>
        <li class="breadcrumb-item active text-uppercase">Blog</li>
      </ol>
    </div>
    <section class="p-t-small">
      <div class="container">
        <header class="mb-5">
          <h1 class="heading-line">Blog</h1>
          <p class="lead">What's new in the world of photography? We are bringing you the latest news, tips and tricks.</p>
        </header>
        <div class="row">
          <div class="col-sm-6">
            <div class="post-item">
              <div class="image"><a href="post.php"><img src="./img/blog1.jpg" alt="" class="img-fluid"></a></div>
              <h4><a href="post.php">Newest photo apps</a></h4>
              <p class="intro">ellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.</p>
              <p class="read-more"><a href="post.php" class="btn btn-unique-outline">Continue reading</a></p>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="post-item">
              <div class="image"><a href="post.php"><img src="./img/blog2.jpg" alt="" class="img-fluid"></a></div>
              <h4><a href="post.php">Best books about Photography</a></h4>
              <p class="intro">ellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.</p>
              <p class="read-more"><a href="post.php" class="btn btn-unique-outline">Continue reading</a></p>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="post-item">
              <div class="image"><a href="post.php"><img src="./img/blog2.jpg" alt="" class="img-fluid"></a></div>
              <h4><a href="post.php">Best books about Photography</a></h4>
              <p class="intro">ellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.</p>
              <p class="read-more"><a href="post.php" class="btn btn-unique-outline">Continue reading</a></p>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="post-item">
              <div class="image"><a href="post.php"><img src="./img/blog1.jpg" alt="" class="img-fluid"></a></div>
              <h4><a href="post.php">Lightroom Tips and Tricks</a></h4>
              <p class="intro">ellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.</p>
              <p class="read-more"><a href="post.php" class="btn btn-unique-outline">Continue reading</a></p>
            </div>
          </div>
        </div>
        <!-- Pagination -->
        <div class="pagination pagination-custom mt-5">
          <nav aria-label="...">
            <ul class="pagination pagination-lg d-flex justify-content-between">
              <li class="page-item"><a href="#" class="page-link">&lt; Older posts</a></li>
              <li class="page-item disabled"><a href="#" tabindex="-1" class="page-link">Newer posts  &gt;                                   </a></li>
            </ul>
          </nav>
        </div>
      </div>
    </section>
    <!-- Search Panel-->
    <div class="search-overlay">
      <div class="search-inner d-flex justify-content-center align-items-center">
        <div class="search-close"><i class="icon-close"></i></div>
        <div class="container">
          <div class="form-holder">
            <form class="d-flex">
              <input type="search" placeholder="What are you looking for...">
              <button type="submit" class="search text-primary text-uppercase">Search</button>
            </form>
          </div>
        </div>
      </div>
    </div>
    <!-- Footer-->
    <?php include("footer.php");?>
  </body>
  <!-- JavaScript files-->
    <script src="./vendor/jquery/jquery.min.js"></script>
    <script src="./vendor/popper.js/umd/popper.min.js"> </script>
    <script src="./vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="./vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="./vendor/owl.carousel/owl.carousel.min.js"></script>
    <script src="./vendor/owl.carousel2.thumbs/owl.carousel2.thumbs.min.js"></script>
    <script src="./vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="./js/front.js"></script>

<!-- Mirrored from demo.bootstrapious.com/photo/1-4/blog.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jan 2019 12:10:44 GMT -->
</html>