<section class="newsletter">
        <div class="container">
          <div class="row">
            <div class="ml-auto mr-auto col-lg-8 text-center">
              <div class="form">
                <p class="h5"><span class="text-primary">Special offers </span>for subscribers</p>
                <h2>New Offers Every Week <span class="text-primary">& </span><br>Discount System <span class="text-primary">&  </span>Best hot prices</h2>
                <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis, error explicabo commodi dolor ex perferendis.</p>
                <form>
                  <input id="email" type="email" name="email" placeholder="Enter your email address">
                  <input type="submit" value="Subscribe" class="btn btn-unique">
                </form>
              </div>
              <div class="social">
                <h2>We are social</h2>
                <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores laborum nesciunt cu.</p>
                <ul class="list-inline">
                  <li class="list-inline-item"><a href="#" target="_blank"><i class="fa fa-facebook"></i></a></li>
                  <li class="list-inline-item"><a href="#" target="_blank"><i class="fa fa-twitter"></i></a></li>
                  <li class="list-inline-item"><a href="#" target="_blank"><i class="fa fa-instagram"></i></a></li>
                  <li class="list-inline-item"><a href="#" target="_blank"><i class="fa fa-behance"></i></a></li>
                  <li class="list-inline-item"><a href="#" target="_blank"><i class="fa fa-pinterest"></i></a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>