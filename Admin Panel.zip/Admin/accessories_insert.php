<?php
include("connection.php");
$accname=$_GET['accname'];
$acccatid=$_GET['acccatid'];
$mediaid=$_GET['mediaid'];
$brandid=$_GET['brandid'];
$warr=$_GET['warranty'];
$des1=$_GET['des1'];
$des2=$_GET['des2'];
$pri=$_GET['price'];
if(!(empty($accname) && empty($mediaid) && empty($brandid) && empty($acccatid) && empty($warr)))
{
	$qry="insert into accessories(acc_name,acc_cat_id,brand_id,media_id,warranty,description1,description2,price)
		values('$accname','$acccatid','$mediaid','$brandid','$warr','$des1','$des2','$pri')";	
}
else
{
	header("location:accessoriesform.php?error=1");
	exit;
}


		//echo $qry;
if(mysqli_query($con,$qry))
{
	header("location:accessories.php");
}
else
{
	echo mysqli_error($con);
}
?>