<?php
include("connection.php");

$cname=$_GET['camname'];
$bid=$_GET['brandid'];
$mid=$_GET['mediaid'];
$des1=$_GET['desc1'];
$des2=$_GET['desc2'];
$des3=$_GET['desc3'];
$warr=$_GET['warranty'];
$bprice=$_GET['bodyprice'];
$lprice=$_GET['bodylenseprice'];
$qry="update camera set
			cam_name='$cname',
			brand_id='$bid',
			media_id='$mid',
			description1='$des1',
			description2='$des2',
			description3='$des3',
			warranty='$warr',
			bodyprice='$bprice',
			bodywithlenseprice='$lprice'
			where cam_id=".$_GET['hdncid']; 
			//echo $qry;
if(mysqli_query($con,$qry))
{
	header("location:camera.php");
}
else
{
	echo mysqli_error($con);
}
?>