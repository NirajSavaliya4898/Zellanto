<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="../admin/image/z.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Zellanto Admin</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/>
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="assets/css/border.css">
</head>
<body>

<div class="wrapper">
    <?php include("sidebar.php");?>
    <div class="main-panel">
		<?php include("navbar.php");?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Edit CustomerDetails</h4>
                            </div>
                            <div class="content">
                                <form action="customer_update_code.php" method="POST" enctype="multipart/form-data">
                                    <?php 
                                    include("connection.php");
                                    $qry="select * from customer WHERE cust_id=".$_REQUEST['cid'];
                                    $result=mysqli_query($con,$qry);
                                    $lst=mysqli_fetch_array($result);
                                    ?>
                                    <div class="row">
                                        <div class="col-md-8">
                                            <div class="group">      
                                              <input type="hidden" Name="hdnaid" required value="<?php echo $lst['cust_id'];?>">
                                              <input type="text" Name="cname" required value="<?php echo $lst['name'];?>">
                                              <span class="highlight"></span>
                                              <span class="bar"></span>
                                              <label>Customer Name</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="group">      
                                              <input type="text" rows="5" Name="add" required value="<?php echo $lst['address']; ?>">
                                              <span class="highlight"></span>
                                              <span class="bar"></span>
                                              <label>Address</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="group">      
                                              <input type="text" Name="cont" required value="<?php echo $lst['contect']; ?>">
                                              <span class="highlight"></span>
                                              <span class="bar"></span>
                                              <label>Contect</label>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="group">      
                                              <input type="text" Name="dob" required value="<?php echo $lst['dob']; ?>">
                                              <span class="highlight"></span>
                                              <span class="bar"></span>
                                              <label>Date Of Birth</label>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="group">      
                                              <input type="text" Name="gender" required value="<?php echo $lst['gender']; ?>">
                                              <span class="highlight"></span>
                                              <span class="bar"></span>
                                              <label>Gender</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="group">      
                                              <input type="email" Name="emailid" required value="<?php echo $lst['email']; ?>">
                                              <span class="highlight"></span>
                                              <span class="bar"></span>
                                              <label>Email ID</label>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="group">      
                                              <input type="text"  Name="password" required value="<?php echo $lst['password']; ?>">
                                              <span class="highlight"></span>
                                              <span class="bar"></span>
                                              <label>Password</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <button type="submit" class="btn btn-dark pull-right">Update</button>
                                    </div>  
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                  </div>
            </div>
        </div>
        <?php include("footer.php");?>
    </div>
</div>
    <?php include("bootomfooter.php");?>
</body>