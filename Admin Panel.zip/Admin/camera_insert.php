<?php
include("connection.php");

$cname=$_GET['camname'];
$bid=$_GET['brandid'];
$mid=$_GET['mediaid'];
$des1=$_GET['desc1'];
$des2=$_GET['desc2'];
$des3=$_GET['desc3'];
$warr=$_GET['warranty'];
$bprice=$_GET['bodyprice'];
$lprice=$_GET['bodylenseprice'];
if(!(empty($accpic) && empty($accname) && empty($acccatid) && empty($mediaid) && empty($brandid) && empty($warr) && empty($pri)))
{
	$qry="insert into camera
		(cam_name,brand_id,media_id,description1,description2,description3,warranty,bodyprice,
		bodywithlenseprice)
		values('$cname','$bid','$mid','$des1','$des2','$des3','$warr','$bprice','$lprice')";
}
else{
	header("location:cameraform.php?error=1");
	exit;
}


		//echo $qry;
if(mysqli_query($con,$qry))
{
	header("location:camera.php");
}
else
{
	echo mysqli_error ($con);
}
?>