<?php
include("connection.php");

$lname=$_GET['lensename'];
$bid=$_GET['brandid'];
$mid=$_GET['mediaid'];
$fsize=$_GET['filtersize'];
$max=$_GET['maxaperature'];
$warr=$_GET['warranty'];
$desc=$_GET['desc'];
$price=$_GET['price'];
if(!(empty($lname) && empty($bid) && empty($mid) && empty($fsize) && empty($max) && empty($warr) && empty($desc) && empty($price)))
{
	$qry="insert into lenses
		(lense_name,brand_id,media_id,filtersize,maxaperature,warranty,description,price)
		values('$lpic','$lname','$bid','$mid','$fsize','$max','$warr','$desc','$price')";
}
else{
	header("location:lenseform.php?error=1");
	exit;
}
		//echo $qry;
if(mysqli_query($con,$qry))
{
	header("location:lense.php");
}
else
{
	echo mysqli_error ($con);
}
?>