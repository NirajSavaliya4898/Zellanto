<?php
include("connection.php");

$name=$_GET['name'];
$ad=$_GET['add'];
$cont=$_GET['cont'];
$dob=$_GET['dob'];
$gen=$_GET['gender'];
$email=$_GET['emailid'];
$pass=$_GET['password'];
if(!(empty($name) && empty($ad) && empty($cont) && empty($dob) && empty($gen) && empty($email) && empty($pass)))
{
	$qry="insert into customer(name,address,contect,dob,gender,email,password)
		values('$name','$ad','$cont','$dob','$gen','$email','$pass')";
}
else{
	header("location:customerform.php?error=1");
	exit;
}

//$result=mysqli_query($con,$qry);
		echo $qry;


if(mysqli_query($con,$qry))
{
	header("location:customer.php");
}
else
{
	echo mysqli_error ($con);
}
?>