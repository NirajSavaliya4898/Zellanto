<?php  
$con=mysqli_connect("localhost","root","") or die("Could not connect");
mysqli_select_db($con,"users") or die("Could not select db"); 

$user_name=$_POST['username'];
$email=$_POST['email']; 
$password=$_POST['pass'];

    $qry="insert into users (user_name,email,password) VALUE ('$user_name',,'$email''$password')";
    if(mysqli_query($con,$qry))
    {
        header("location:login.php");
    }
    else
    {
        echo mysqli_error ($con);
    } 
        
?>