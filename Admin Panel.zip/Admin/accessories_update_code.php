<?php
include("connection.php");

$accname=$_GET['accname'];
$acccatid=$_GET['acccatid'];
$mediaid=$_GET['mediaid'];
$brandid=$_GET['brandid'];
$warr=$_GET['warranty'];
$des1=$_GET['des1'];
$des2=$_GET['des2'];
$pri=$_GET['price'];
$qry="update accessories set
			acc_name='$accname',
			acc_cat_id='$acccatid',
			brand_id='$brandid',
			media_id='$mediaid',
			warranty='$warr',
			description1='$des1',
			description2='$des2',
			price='$pri'
			where Acc_id=".$_GET['hdnaid']; 
			echo $qry;
if(mysqli_query($con,$qry))
{
	header("location:accessories.php");
}
else
{
	echo mysqli_error($con);
}
?>