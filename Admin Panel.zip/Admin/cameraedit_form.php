<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="../admin/image/z.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Zellanto Admin</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/>
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="assets/css/border.css">
</head>
<body>

<div class="wrapper">
    <?php include("sidebar.php");?>
    <div class="main-panel">
		<?php include("navbar.php");?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Edit CameraDetails</h4>
                            </div>
                            <div class="content">
                                <form action="camera_update_code.php">
                                    <?php 
                                    include("connection.php");
                                    $qry="select * from camera WHERE cam_id=".$_REQUEST['cid'];
                                    $result=mysqli_query($con,$qry);
                                    $lst=mysqli_fetch_array($result);
                                    ?>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="group"> 
                                              <input type="hidden" Name="hdncid" value="<?php echo $lst['cam_id'];?>">     
                                              <input type="text" Name="camname" required placeholder="" value="<?php echo $lst['cam_name'];?>">
                                              <span class="highlight"></span>
                                              <span class="bar"></span>
                                              <label>Camera Name</label>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="group">      
                                              <input type="text" Name="brandid" required placeholder="" value="<?php echo $lst['brand_id'];?>">
                                              <span class="highlight"></span>
                                              <span class="bar"></span>
                                              <label>Brand ID</label>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="group">
                                                <button type="button" class="btn btn-dark pull" data-toggle="modal" data-target="#exampleModal"> Add Media 
                                                </button>
                                                <img id="media_image" height="100px" width="100px" name="media_image" style="visibility:hidden;" src="">
                                                <input type="hidden" name="txtmid" id="txtmid">
                                              <span class="highlight"></span>
                                              <span class="bar"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="group">      
                                              <input type="text" rows="5" Name="desc1" required placeholder="" value="<?php echo $lst['description1'];?>">
                                              <span class="highlight"></span>
                                              <span class="bar"></span>
                                              <label>Description1</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="group">      
                                              <input type="text" rows="5" Name="desc2" required placeholder="" value="<?php echo $lst['description2'];?>">
                                              <span class="highlight"></span>
                                              <span class="bar"></span>
                                              <label>Description2</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="group">      
                                              <input type="text" rows="5" Name="desc3" required placeholder="" value="<?php echo $lst['description3'];?>">
                                              <span class="highlight"></span>
                                              <span class="bar"></span>
                                              <label>Description3</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="group">      
                                              <input type="text" Name="warranty" required placeholder="" value="<?php echo $lst['warranty'];?>">
                                              <span class="highlight"></span>
                                              <span class="bar"></span>
                                              <label>Warranty</label>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="group">      
                                              <input type="text" Name="bodyprice" required placeholder="" value="<?php echo $lst['bodyprice'];?>">
                                              <span class="highlight"></span>
                                              <span class="bar"></span>
                                              <label>Body Price</label>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="group">      
                                              <input type="text" Name="bodylenseprice" required placeholder="" value="<?php echo $lst['bodywithlenseprice'];?>">
                                              <span class="highlight"></span>
                                              <span class="bar"></span>
                                              <label>Body+Lense Price</label>
                                            </div>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-dark pull-right">Update</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                  </div>
            </div>
        </div>
        <?php include("footer.php");?>
    </div>
</div>
    <?php include("bootomfooter.php");?>
</body>
                                    