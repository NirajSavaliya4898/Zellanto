<?php
include("connection.php");

$name=$_POST['cname'];
$ad=$_POST['add'];
$cont=$_POST['cont'];
$dob=$_POST['dob'];
$gen=$_POST['gender'];
$email=$_POST['emailid'];
$pass=$_POST['password'];
$qry="update customer set
			name='$name',
			address='$ad',
			contect='$cont',
			dob='$dob',
			gender='$gen',
			email='$email',
			password='$pass'
			where Cust_id=".$_POST['hdnaid']; 
			//echo $qry;
if(mysqli_query($con,$qry))
{
	header("location:customer.php");
}
else
{
	echo mysqli_error($con);
}
?>