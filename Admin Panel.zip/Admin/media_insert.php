<?php
include("connection.php");
$url=$_FILES['mediaurl']['name'];
$title=$_POST['mediatitle'];
$des=$_POST['desc'];
echo $_FILES['url']['tmp_name'];
if(!(empty($url) && empty($title)))
{
if(move_uploaded_file($_FILES['mediaurl']['tmp_name'],"../Admin/media/".$_FILES['mediaurl']['name']))
{
	$qry="insert into media(media_url,media_title,description)
		values('$url','$title','$des')";
}
else{
	header("location:media_insert.php?error=1");
	exit;
}

}
		//echo $qry;
if(mysqli_query($con,$qry))
{
	header("location:media.php");
}
else
{
	echo mysqli_error ($con);
}
?>