<div class="sidebar" data-color="black" data-image="assets/img/sidebar-4.jpg">
    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="http://localhost/zellanto/" class="simple-text">
                    Zellanto
                </a>
            </div><br/>
            <ul class="nav">
                <li class="active">
                    <a href="dashboard.php">
                        <i class="pe-7s-graph"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li>
                    <a href="user.php">
                        <i class="pe-7s-user"></i>
                        <p>User Profile</p>
                    </a>
                </li>
                <li>
                    <a href="slider.php">
                        <i class="pe-7s-note2"></i>
                        <p>Slider</p>
                    </a>
                </li>
                <li>
                    <a href="customer.php">
                        <i class="pe-7s-note2"></i>
                        <p>Customer</p>
                    </a>
                </li>
                <li>
                    <a href="category.php">
                        <i class="pe-7s-note2"></i>
                        <p>Category</p>
                    </a>
                </li>
                <li>
                    <a href="media.php">
                        <i class="pe-7s-note2"></i>
                        <p>Media</p>
                    </a>
                </li>    
                <li>
                    <a href="brand.php">
                        <i class="pe-7s-note2"></i>
                        <p>Brand</p>
                    </a>
                </li>
                <li>
                    <a href="camera.php">
                        <i class="pe-7s-note2"></i>
                        <p>Cameras</p>
                    </a>
                </li>
                <li>
                    <a href="lense.php">
                        <i class="pe-7s-note2"></i>
                        <p>Lenses</p>
                    </a>
                </li>
                <li>
                    <a href="accessoriesmaster.php">
                        <i class="pe-7s-note2"></i>
                        <p>AccessoriesMaster</p>
                    </a>
                </li>
                <li>
                    <a href="accessories.php">
                        <i class="pe-7s-note2"></i>
                        <p>Accessories</p>
                    </a>
                </li>
                <li>
                    <a href="table.php">
                        <i class="pe-7s-note2"></i>
                        <p>Table List</p>
                    </a>
                </li>
                <li>
                    <a href="typography.php">
                        <i class="pe-7s-news-paper"></i>
                        <p>Typography</p>
                    </a>
                </li>
                <li>
                    <a href="icons.php">
                        <i class="pe-7s-science"></i>
                        <p>Icons</p>
                    </a>
                </li>
                <li>
                    <a href="maps.php">
                        <i class="pe-7s-map-marker"></i>
                        <p>Maps</p>
                    </a>
                </li>
                <li>
                    <a href="notifications.php">
                        <i class="pe-7s-bell"></i>
                        <p>Notifications</p>
                    </a>
                </li>
            </ul>
            <ul class="nav">
                <li>
                    <a href="upgrade.php">
                        <i class="pe-7s-rocket"></i>
                        <p>Upgrade to PRO</p>
                    </a>
                </li>
            </ul>
    	</div>
    </div>