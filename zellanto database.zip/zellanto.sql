-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 10, 2019 at 08:08 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `zellanto`
--

-- --------------------------------------------------------

--
-- Table structure for table `accessories`
--

CREATE TABLE `accessories` (
  `Acc_id` int(11) NOT NULL,
  `acc_name` varchar(70) NOT NULL,
  `acc_cat_id` int(4) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `media_id` int(11) NOT NULL,
  `warranty` char(1) NOT NULL,
  `description1` text NOT NULL,
  `description2` text NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accessories`
--

INSERT INTO `accessories` (`Acc_id`, `acc_name`, `acc_cat_id`, `brand_id`, `media_id`, `warranty`, `description1`, `description2`, `price`) VALUES
(1, 'Simpex 888 Tripod (Supports upto 5000 g)', 2, 6, 30, '1', ' Tripod Weight: 1.8 Kg  Vertical Leg Locks  Geared Elevator ', 'Leg Diameter: 26.8 mm  Leg Brace with Lock  View all item details', '3890.00'),
(2, 'Simpex 333 Aluminium Standard Tripod White', 2, 6, 31, '1', 'Max Load Capacity (in kg):Upto 3  Pan Head:3way', 'Simpex 333 Tripod, Features:Aluminum Oval Section, Tripod Set and Carrying Case', '999.00'),
(3, 'Simpex 1055 Monopod - Black', 3, 6, 32, '1', 'Product Type : Monopod  Features : Lightweight Structure', '\r\nIN THE BOX\r\nSales Package	Main Unit, 1 x Carrying Bag\r\nGENERAL\r\nBrand	Simpex\r\nModel	1055\r\nType	Monopod\r\nColor	Black\r\nSPECIFICATION\r\nLoad Capacity	3000 g\r\nMaterial	Aluminium Alloy Material\r\nADDITIONAL FEATURES\r\nOther Features	Lightweight Structure', '1790.00'),
(4, 'Simpex 552 Black Monopod', 3, 6, 33, '0', ' Max Load Capacity (in kg):10  Warranty (in months):0', '\r\nGeneral\r\nModel Name	552\r\nColor	Black\r\nProduct Weight (in gm)	1005\r\nSupplied Accessories	1 Monopod, 1 Carry Case\r\nProduct Length (in cm)	9\r\nProduct Breath (in cm)	9\r\nProduct Height (in cm)	68\r\nFeatures\r\nMaximum Height (in cm)	1685\r\nMinimum Height (in cm)	598\r\nFolded Length (in cm)	9\r\nMax Load Capacity (in kg)	10', '4135.00'),
(5, 'Simpex 522 Flash Camera Accessories', 7, 6, 34, '1', ' Product Type : Flash  Features : Power Up: Increase the po....', 'Power up: increase the power output of the flash; power down: decreases the power output of the flash', '2680.00'),
(6, 'Simpex 621RX', 7, 6, 35, '1', ' Model Name:621RX  Color:Black  Mode:Auto & Manual  ', 'Box Content:Manual, Flash, Remote for Flash, 1 Flash Mini Stand  Recycling Time:NA', '3988.00'),
(7, 'Canon LP-E6 Original Battery for EOS 5D Mark II, 5', 4, 1, 36, '2', 'Product Type : Battery  Compact and light weighted  Output Voltage: 7.2 V  High Capacity replacement Lithium-Ion Battery  Capacity: 1800 mAh', 'Canon Camera EOS 5D Mark II, Battery Part Number- LP-E6. Replacement Lithium-Ion Battery is a rechargeable 1800 mAh, 7.2 Volts Camera battery. It is compatible to Canon EOS 5D Mark II, Canon EOS 5D Mark III, Canon EOS 6D, Canon EOS 7D, Canon EOS 60D, Canon EOS 60 Da camera.', '1259.00'),
(8, 'Sony NP-FW50 InfoLITHIUM Rechargeable Battery', 4, 2, 37, '1', 'Provides Extended Movie/Photo Shooting  57 grams Weight  Compact  7.7Wh Capacity', 'Sony NP-FW50 InfoLITHIUM Rechargeable Battery', '1192.00'),
(9, 'Nikon EN-EL 14 A Rechargeable Li-ion battery for N', 4, 3, 38, '1', 'product Type : Battery Charger', 'Product Type : Battery Charger	SUPC: SDL907001699', '1093.00'),
(10, 'Nikon MH-24 Camera Battery Charge', 5, 3, 39, '1', 'Model Name:MH-24  Compatible Battery Type:9V', 'General\r\nCompatible Battery Type	9V\r\nIn the box	1 Battery 1 Charger\r\nOriginal/Replacement Copy	Original', '739.00'),
(11, 'Canon LC-E8E Battery Charger (4520B001AA)', 5, 1, 40, '1', ' Power Requirements: 110-240VAC 50/60 Hz  Charger for LP-E8 Batteries  Power Requirements: 110-240VAC ', '\r\nSpecification\r\nBrand	Canon\r\nModel	LC-E8E\r\nPower Requirements	110-240VAC 50/60 Hz\r\nWarranty	1-Year Canon India Warranty and Free Transit Insurance\r\n', '875.00'),
(12, 'Sony NP-BN1 Camera Battery Charger', 5, 2, 41, '1', 'Model Name:NP-BN1  Compatible Battery Type:9V  No of Charging Slots:1', 'Compatible Battery Type	9V\r\nNo of Charging Slots	1\r\nPower Input	3.7\r\nCharging Time	3-5 hours\r\nIn the box	1 Combo Battery Charger\r\nProduct Length (in cm)	5\r\nProduct Weight (in gm)	15\r\nProduct Breath (in cm)	4\r\nProduct Height (in cm)	5', '1399.00'),
(13, 'Digitek Speedlite DFL 003 Macro', 7, 7, 42, '1', 'Model Name:Speedlite DFL 003  Type:Macro  Color:Black  ', 'Mode:Manual  Recycling Time:0.1 - 5 s', '1990.00'),
(14, 'Sonia Porta Light For Video and Continuous Lightin', 7, 8, 43, '1', ' Product Type : Flashlights', 'Bad lighting will not spoil your pictures anymore with this Sonia Porta Light. It can be used for outdoor photo shoot purposes. These lighting systems are needed for fashion photography, photo shoots, modelling assignment, studios and many others. The clarity of a picture depends on the quality and quantity of light it receives. This adjustable light will therefore help you to get the perfect angle and right amount of exposure.', '1992.00'),
(15, 'Digitek LED Light 204C', 7, 7, 44, '1', 'Model Name:LED Light 204C  Color:Black  Mode:Manual  Box Content:LED Light, Mounting Hot Shoe,Color Filter And Lithium Ion Battery With Charger  Other Features:Average Life Span 30000h, Lumens 1440, Illumination 1 M:400 Lux, Color Temperature 3200 K-5500 K,', 'Digitek led video light LED-D204C', '2296.00'),
(16, 'Canon EF-S 18-55 AND 55-250 IS II AND STM LENS UV ', 8, 1, 45, '2', ' Model Name:EF-S 18-55 AND 55-250 IS II AND STM LENS  Type:UV Filter  Filter Diameter (in mm):58  Box Content:1', '58Mm UV Filter For EF-S 18-55 IS II , STM , EF-S 55-250 IS II , STM LENS', '999.00'),
(17, 'DigiTek 67 MM UV Filter (Black)', 8, 7, 46, '1', 'Product Type : Filters', 'Noted for offering you maximum light transmission and crystal clear imaging experience, the filter easily cuts all the UV rays without affecting colour balance. It is made from high index optical glass and ensures that you get the best results under all testing conditions. Use this high-performance and reliable UV filter and get cleaner and sharper pictures once you release the shutter. It doubles up as a lens protector for your camera as well. Specifications: This filter cuts all range of UV rays to give cleaner and sharper pictures with less haze, without affecting color balance. These popular filters are renowned for their ability to minimize reflection at the filter surfaces which reduces flare and ghosting', '393.00'),
(18, 'Digitek Digitek / Simpex Mini Flash Bouncer', 9, 7, 47, '1', 'Model Name:Digitek / Simpex Mini Flash Bouncer  Color:White  Box Content:1 pieces Mini Bouncer', 'Digitek / Simpex Flash Mini Bouncer', '349.00'),
(19, 'Sonia Flash Diffuser Lambency Diffuser', 9, 7, 48, '1', 'roduct Type : Flash Diffuser', 'Contents Sonia Lambency Diffuser - 1 no Dome - 4 no Features It is a set of diffuser with four domes white, yelow, orange, & blue along with a diffuser cloth,', '569.00'),
(20, 'Sonia Monopod Pro-111 with Self Standing Legs & Ba', 3, 8, 49, '1', ' Product Type : Monopod', 'Brand	Sonia\r\nModel	Pro111-3L-BH\r\nType	Monopod\r\nColour	Black & Silver\r\n\r\n\r\n', '492.00'),
(21, 'Sonia Ph 660 Tripod (Load Capacity 3000 g)', 2, 8, 50, '1', ' High Grade Aluminium Body  3-Way Pan Head  Quick Flip Leg Locks  Quick Release Plate  Geared Elevator', 'Popular brand Sonia brings to you this utilitarian Sonia Ph 660 Tripod that allows users to hold the camera in a proper position and click pictures. \r\n', '1964.00'),
(22, 'Scratchgard Screen Protector for Nikon D3300', 6, 9, 51, '0', 'Compatible DSLR Models:Nikon D3300  Other Features:This Is Plastic PET FILM Scratchgard,  Box Content:1 Scratchgard & 1 Micro Fiber Cloth  Type:Camera Scratchgard  Product Weight (in gm):0.1', 'Protect your Camera display against scratches and dust with this screen guard. It can also protect your screen from fingerprints so that your display stays clean and offers crystal clarity while viewing.', '500.00'),
(23, 'SHOPEE Nikon DK-21 DK 21 EyeCup Eyepiece replaceme', 6, 3, 52, '1', 'Model:Nikon DK-21 DK 21 EyeCup Eyepiece replacement  Compatible DSLR Models:Camera a', 'Replacement for your Lost Eyepiece Suitable For NIKON D7000 D300 D200 D70s D80 D90 D100 D50 The Eyecup provides cushioning around the camera\'s eyepiece,and is especially useful to eyeglass wearers Made of rubber for soft eye contact. You can even view it with your glasses on', '300.00'),
(24, 'Nikon Shoulder Camera Bag (Black)', 1, 3, 53, '1', 'No. of Compartments:3  Bottle Pocket:Yes  Features:Hand Strap', 'A photographer\'s ideal friend a photographer\'s most prized possession is undoubtedly the camera. But daily usage and extreme weather can cause damage to your precious device.', '1050.00'),
(25, 'Canon 200D Camera Bag (Black)', 1, 1, 54, '1', 'Ideal for DSLR/SLR Cameras  Adjustable Shoulder Strap  Zippered Compartments  Padded Interiors  Unisex Design', 'If you are looking for a DSLR camera bag which is not only affordable but also protective and stylish, Canon 1200D SLR Camera Bag is the one you should go for.', '599.00'),
(26, 'Nylon K&F Concept Pro Camera Tripod Backpack Bag ', 1, 2, 55, '1', 'Specification: Color: Black + Dark Blue Material: Nylon\nLining: Grey 210D NylonSize: (L)X(W)X(H)34X18X49cm/13.38\"X7.08\"X19.29\"(appr.)', 'Features: Brand New and high quality.It has the functions of wear resistance, weight reduction, waterproof, anti-theft and moisture proof. It is a good choice for outdoor, tourism and leisure\n2.', '5577.00');

-- --------------------------------------------------------

--
-- Table structure for table `accessoriesmaster`
--

CREATE TABLE `accessoriesmaster` (
  `Acc_cat_id` int(4) NOT NULL,
  `acc_cat` varchar(100) NOT NULL,
  `description` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accessoriesmaster`
--

INSERT INTO `accessoriesmaster` (`Acc_cat_id`, `acc_cat`, `description`) VALUES
(1, 'camera bags', 'camera bags'),
(2, 'tripods', 'tripods\r\n'),
(3, 'monopods', 'monopods'),
(4, 'batteries', 'batteries'),
(5, 'battery chargers', 'battery chargers'),
(6, 'screen protectors', 'screen protectors'),
(7, 'flashes', 'flashes'),
(8, 'filters', 'filters\r\n'),
(9, 'flash diffuser', 'flash diffuser');

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `brand_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `brandusefor` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`brand_id`, `name`, `description`, `brandusefor`) VALUES
(1, 'Canon', 'Canon', ''),
(2, 'Sony', 'Sony', ''),
(3, 'Nikon', 'Nikon', ''),
(5, 'Fujifilm', 'Fujifilm', ''),
(6, 'Simpex', 'Simpex\r\n', ''),
(7, 'Digitek', 'Digitek\r\n', ''),
(8, 'Sonia', 'Sonia', 'photography');

-- --------------------------------------------------------

--
-- Table structure for table `camera`
--

CREATE TABLE `camera` (
  `cam_id` int(11) NOT NULL,
  `cam_name` varchar(50) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `media_id` int(11) NOT NULL,
  `description1` text NOT NULL,
  `description2` text NOT NULL,
  `description3` text NOT NULL,
  `warranty` char(1) NOT NULL COMMENT '1,2,3 year',
  `bodyprice` decimal(10,2) NOT NULL,
  `bodywithlenseprice` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `camera`
--

INSERT INTO `camera` (`cam_id`, `cam_name`, `brand_id`, `media_id`, `description1`, `description2`, `description3`, `warranty`, `bodyprice`, `bodywithlenseprice`) VALUES
(1, 'EOS R (RF24-105mm f/4L IS USM)', 1, 1, '30.3MP Full-Frame CMOS Sensor', '0.05 secs focusing time', '5,655 selectable focus positions', '2', '174990.00', '256990.00'),
(2, 'EOS 6D Mark II Kit (EF24-105mm f/4L IS II USM)', 1, 2, '26.2MP Full-frame CMOS Sensor', 'Dual Pixel CMOS AF', '45-point all cross-type AF; up to 6.5fps continuous shooting', '2', '171900.00', '0.00'),
(3, 'EOS 5D Mark IV Kit (EF 24 - 105 IS II USM)', 1, 3, '30.4MP Full-frame CMOS Sensor', 'Dual Pixel CMOS AF', '4K Movie Shooting (25 / 30p) with 4K Frame Grab', '2', '236890.00', '0.00'),
(4, 'EOS 200D Kit (EF-S18-55 IS STM & EF-S55-250 IS STM', 1, 4, 'Compact and lightweight design', 'Quick focusing in Live View mode with Dual Pixel CMOS AF', 'Vari-angle touchscreen LCD', '2', '50460.00', '0.00'),
(5, 'EOS 77D Kit (EF-S18-135 IS USM)', 1, 5, 'Dual Pixel CMOS AF', 'Wi-Fi / NFC and Bluetooth Low Energy', 'Up to 45-point All Cross-type AF', '2', '72990.00', '0.00'),
(6, 'A7R III 35 mm full-frame camera with autofocus', 2, 6, '42.4 MP 35 mm full-frame Exmor R™ CMOS and enhanced processing system', 'Standard ISO 100-32000 range (upper limit expandable to 1024007)', 'Fast Hybrid AF with 399-point focal-plane phase-detection AF and 425-point contrast-detection AF', '3', '248490.00', '350000.00'),
(7, 'A9 mirrorless camera with CMOS sensor', 2, 7, '24.2-megapixel 35 mm full-frame stacked CMOS sensor with integral memory', 'BIONZ X™ image processing engine\r\n\r\nHigh-speed continuous shooting of up to 20fps with AF/AE tracking', '693-point wide-area phase-detection AF\r\n\r\nFive-axis image stabilisation with effectiveness equivalent to 5.0-stop slower shutter speed', '3', '308490.00', '490990.00'),
(8, 'A7S II E-mount Camera with Full-Frame Sensor', 2, 8, '35 mm full frame (35.6 x 23.8 mm), Exmor® CMOS sensor\r\n\r\nBIONZ X™ image processing engine', '4K movie recording featuring full pixel readout without pixel binning', '5-axis optical image stabilisation minimises blur\r\n\r\n3 year warranty', '3', '188490.00', '285490.00'),
(9, 'A7 III with 35 mm full-frame image sensor', 2, 9, '24.2MP7 35 mm full-frame CMOS sensor with back-illuminated design', 'Sensitivity range up to ISO 51200 (expandable to ISO 50-204800 for stills)', 'High-speed continuous shooting of up to 10fps4 with AF/AE tracking\r\n4K HDR5 6 movie recording capability', '3', '158490.00', '171990.00'),
(10, 'D3500', 3, 10, 'AF-P DX NIKKOR 18-55mm f/3.5-5.6G VR + AF-P DX NIKKOR 70-300mm f/4.5-6.3G ED VR)', 'Price quoted is MRP inclusive of all taxes for one unit of the product.\r\nIncludes 16GB(Class 10) SD Card + Carry Case', 'Offer lens included in D-ZOOM kit retail pack, no additional lens offer applicable. D-ZOOM kit is available in black color only.', '2', '29450.00', '34450.00'),
(11, 'D850', 3, 0, '(with 24-120mm VR Lens)', 'Includes 64 GB (Class 10) SD card', 'Price quoted is MRP inclusive of all taxes for one unit of the product.', '2', '234950.00', '321950.00'),
(12, 'D7500', 3, 0, 'Rs.106250.00 Offer Price:Rs.98950.00 (with AF-S NIKKOR 18-140mm VR lens', 'Rs.106250.00 Offer Price:Rs.98950.00 (with AF-S NIKKOR 18-105mm VR lens)', 'Price quoted is MRP inclusive of all taxes for one unit of the product.Includes 16GB(Class 10) SD card & Carry CaseDX D-SLR Kit + Lens Combo Offer!!', '2', '88950.00', '106250.00'),
(14, 'FUJIFILM GFX 50R', 4, 13, 'Rangefinder style\r\nCompact and lightweight body', 'Weather resistant structure\r\n43.8x32.9mm 51.4MP CMOS medium format sensor', 'X-Processor Pro\r\n2.36M-dot touchscreen LCD back panel\r\nFUJINON GF Lens', '1', '0.00', '340999.00'),
(15, 'FUJIFILM GFX 50S', 4, 0, 'New Firmware Ver.3.10\r\n43.8x32.9mm 51.4MP CMOS medium format sensor\r\nX-Processor Pro', 'Detachable 3.69M-dot EVF\r\n2.36M-dot touchscreen LCD back panel\r\nCompact and lightweight body', 'Weather resistant structure\r\nFUJINON GF Lens', '', '399999.00', '450990.00'),
(16, 'FUJIFILM X-T3', 4, 14, 'New X-Trans™* CMOS 4 & X-Processor 4\r\nNew Phase detection AF to entire frame\r\nNew Up to 30 fps** black-out free high-speed continuous shooting', 'New Sports finder mode\r\nNew Monochrome Adjustment\r\nNew Color Chrome Effect', 'New 4K/60P 10 bit recording\r\nWeather resistant structure', '2', '108699.00', '138199.00');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` int(4) NOT NULL,
  `cat_name` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `media_url` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`, `description`, `media_url`) VALUES
(1, 'Camera', 'Camera', 'camera.jpg'),
(2, 'Lenses', 'Lense', 'lenses.jpg'),
(4, 'Accessories', 'Accessories', 'accessories.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cust_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `contect` varchar(15) NOT NULL,
  `dob` date NOT NULL,
  `gender` char(6) NOT NULL COMMENT 'M,F',
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cust_id`, `name`, `address`, `contect`, `dob`, `gender`, `email`, `password`) VALUES
(1, 'Nayan', 'varachha', '7567716693', '1999-09-16', 'm', 'njthummar0@gmail.com', '12345678');

-- --------------------------------------------------------

--
-- Table structure for table `lenses`
--

CREATE TABLE `lenses` (
  `lense_id` int(11) NOT NULL,
  `lense_name` varchar(50) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `media_id` int(11) NOT NULL,
  `filtersize` varchar(50) NOT NULL,
  `maxaperature` varchar(50) NOT NULL,
  `warranty` char(1) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lenses`
--

INSERT INTO `lenses` (`lense_id`, `lense_name`, `brand_id`, `media_id`, `filtersize`, `maxaperature`, `warranty`, `description`, `price`) VALUES
(1, 'EF70-200mm f/2.8L IS III USM', 1, 16, '77mm', 'f/2.8', '1', 'With ring USM motor and IS (approx. 3.5 stops)', '125000.00'),
(2, 'EF70-200mm f/4L IS II USM', 1, 17, '72mm', 'f/4', '1', 'With ring USM motor and IS (up to approx. 5 stops)', '135000.00'),
(3, 'EF-S35mm f/2.8 Macro IS STM', 1, 18, '49mm ', 'f/2.8', '1', 'Built-in Macro Lite', '25995.00'),
(4, 'EF16-35mm f/2.8L III USM', 1, 19, '82mm', 'f/2.8', '1', 'With ring USM motor', '161995.00'),
(5, 'EF-S18-135mm f/3.5-5.6 IS USM', 1, 20, '67mm', 'f/3.5-5.6', '1', 'With Nano USM motor and IS', '36595.00'),
(6, 'AF-S NIKKOR 500MM F/5.6E PF ED VRNEW', 3, 21, ' 95 mm (P = 1.0 mm)', ' f/ 5.6', '1', 'Price quoted is MRP inclusive of all taxes for one unit of the product.', '284950.00'),
(7, 'AF-S NIKKOR 180-400MM F/4E TC1.4 FL ED VR', 3, 22, ' Approx. 128 mm x 362.5 mm', 'Without built-in teleconverter: f/ 4 With built-in', '1', '\r\nLC-K103 slip-on Front Lens Cap, LF-4 Rear Lens Cap, HK-41 Lens Hood, Dedicated slip-in Filter Holder*, 40.5 mm screw-on Neutral Color (NC) filter, LN-2 Strap, CL-L2 Lens Case * Dedicated accessories are not available for general purchase. Contact a Nikon-authorized service representative for spares or replacements.', '849950.00'),
(8, 'AF-P NIKKOR 70-300MM F/4.5-5.6E ED VR', 3, 23, ' Approx. 80.5 mm  x 146 mm', ' f/ 4.5 to 5.6', '1', '\r\nLC-67 67 mm snap-on Front Lens Cap, LF-4 Rear Lens Cap, HB-82 Bayonet Hood, CL-1022 Lens Case', '47950.00'),
(9, 'AF-P DX NIKKOR 10-20MM F/4.5-5.6G VR', 3, 24, ' Approx. 77.0 mm x 73.0 mm ', ' f/ 4.5 to 5.6', '1', '\r\nLC-72 72 mm snap-on Front Lens Cap, LF-4 Rear Lens Cap, HB-81 Bayonet Hood, CL-1015 Lens Case', '24950.00'),
(10, 'FE 400 mm F2.8 GM OSS', 2, 25, '40.5 (slot-in)', '2.7 m (8.86 ft)', '1', 'Premium G Master series large-aperture super telephoto lens\r\nNewly developed XD Linear Motor for extremely fast, precise, quiet AF\r\nThree fluorite lenses for outstanding resolution', '1034990.00'),
(11, 'FE 24mm F1.4 GM', 2, 26, '67', '0.24 m (0.79 ft)', '1', 'Premium G Master Series Wide-range prime lens\r\nDDSSM (Direct Drive SSM) for quiet, highly precise focus lens control\r\nCircular 11-blade aperture for beautiful defocus effects\r\nTwo XA (extreme aspherical) elements in an optical design contribute to G Master\'s high resolution', '129990.00'),
(12, 'E 18-135mm F3.5-5.6 OSS', 2, 0, '55', '0.45 m (1.48 ft)', '1', 'APS-C high-magnification standard zoom lensAdvanced optical design incorporating an aspherical element for high corner-to-corner resolutionAdvanced linear motor technology for fast, precise and quiet focus control', '51990.00'),
(13, 'FUJINON LENS GF45mmF2.8 R WR', 4, 28, '23.0mm', 'F11.0', '1', 'FUJINON GF45mmF2.8 R WR Lens is a highly versatile wide angle lens with a focal length equivalent to 36mm (on a 35mm format) and maximum F2.8 aperture. Thanks to its compact and lightweight design (weighing only 490g), this lens is ideal for street and documentary photography.', '133999.00'),
(14, 'FUJINON LENS GF110mmF2 R LM WR', 4, 29, '110.0mm', 'F2.0', '1', 'GF lenses achieve ultra-high resolution and are capable of supporting further enhancement in future. Utilizing the knowledge cultivated through the development of the XF lenses, GF lenses are Fujifilm\'s finest class of lenses and were designed by amassing various technologies of Fujifilm. They are designed to fully unlock performance potential of the GFX 50S.', '219999.00');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `contect` int(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `media_id` int(100) NOT NULL,
  `media_url` varchar(50) NOT NULL,
  `media_title` varchar(50) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`media_id`, `media_url`, `media_title`, `description`) VALUES
(2, 'EOS 6D Mark II.jpg', 'EOS 6D Mark II Kit ', '26.2MP Full-frame CMOS Sensor\r\nDual Pixel CMOS AF\r\n45-point all cross-type AF; up to 6.5fps continuoues'),
(3, 'EOS 5D Mark IV.jpg', 'EOS 5D Mark IV Kit ', '30.4MP Full-frame CMOS Sensor\r\nDual Pixel CMOS AF\r\n4K Movie Shooting (25 / 30p) with 4K Frame Grab'),
(4, 'EOS 200D.jpg', 'EOS 200D Kit ', 'Compact and lightweight design\r\nQuick focusing in Live View mode with Dual Pixel C...\r\nVari-angle touchscreen LCD'),
(5, 'EOS 77D.jpg', 'EOS 77D Kit ', 'Dual Pixel CMOS AF\r\nWi-Fi / NFC and Bluetooth Low Energy\r\nUp to 45-point All Cross-type AF'),
(6, 'A7R III 35 mm.jpg', 'A7R III 35 mm full-frame camera', '42.4 MP 35 mm full-frame Exmor Râ„¢ CMOS and enhance...\r\nStandard ISO 100-32000 range (upper limit expandab...\r\nFast Hybrid AF with 399-point focal-plane phase.'),
(7, 'A9 mirrorless camera.jpg', 'A9 mirrorless camera ', '24.2-megapixel 35 mm full-frame stacked CMOS senso...\r\nBIONZ Xâ„¢ image processing engine\r\n\r\nHigh-speed con...\r\n693-point wide-area phase-detection AF.'),
(8, 'A7S II E-mount.jpg', 'A7S II E-mount Camera ', '35 mm full frame (35.6 x 23.8 mm), ExmorÂ® CMOS sen...\r\n4K movie recording featuring full pixel readout wi...\r\n5-axis optical image stabilisation minimises blur.'),
(9, 'A7 III with 35 mm full-frame image sensor.jpg', 'A7 III with 35 mm full-frame image sensor', '24.2MP7 35 mm full-frame CMOS sensor with back-ill...\r\nSensitivity range up to ISO 51200 (expandable to I...\r\nHigh-speed continuous shooting of up to 10fps4.'),
(10, 'D3500.jpg', 'D3500', 'AF-P DX NIKKOR 18-55mm f/3.5-5.6G VR + AF-P DX NIK...\r\nPrice quoted is MRP inclusive of all taxes for one...\r\nOffer lens included in D-ZOOM kit retail pack.'),
(11, 'D850.JPG', 'D850', '(with 24-120mm VR Lens)\r\nIncludes 64 GB (Class 10) SD card\r\nPrice quoted is MRP inclusive of all taxes for one.'),
(12, 'D7500.jpg', 'D7500', 'Rs.106250.00 Offer Price:Rs.98950.00 (with AF-S NIKKOR 18-105mm VR lens)\r\nRs.106250.00 Offer Price:Rs.98950.00 (with AF-S NIKKOR 18-140mm VR lens).\r\nPrice quoted is MRP inclusive of all taxes for one.'),
(13, 'FUJIFILM GFX 50R.jpg', 'FUJIFILM GFX 50R', 'Rangefinder style\r\nCompact and lightweight body\r\nWeather resistant structure\r\n43.8x32.9mm 51.4MP CM...\r\nX-Processor Pro\r\n2.36M-dot touchscreen LCD back.'),
(14, 'FUJIFILM GFX 50S.jpg', 'FUJIFILM GFX 50S', 'New Firmware Ver.3.10\r\n43.8x32.9mm 51.4MP CMOS med...\r\nDetachable 3.69M-dot EVF\r\n2.36M-dot touchscreen LCD\r\nWeather resistant structure\r\nFUJINON GF Lens'),
(15, 'FUJIFILM X-T3.jpg', 'FUJIFILM X-T3', 'New X-Transâ„¢* CMOS 4 & X-Processor 4\r\nNew Phase de...\r\nNew Sports finder mode\r\nNew Monochrome Adjustment\r\n...\r\nNew 4K/60P 10 bit recording\r\nWeather resistant.'),
(16, 'EF70-200mm.jpg', 'EF70-200mm f/2.8L IS III USM', 'With ring USM motor and IS (approx. 3.5 stops)'),
(17, 'EF70-200mm f4L.jpg', 'EF70-200mm f/4L IS II USM', 'With ring USM motor and IS (up to approx. 5 stops)'),
(18, 'EF-S35mm.jpg', 'EF-S35mm f/2.8 Macro IS STM', 'Built-in Macro Lite'),
(19, 'EF16-35mm.jpg', 'EF16-35mm f/2.8L III USM', 'With ring USM motor'),
(20, 'EF-S18-135mm.jpg', 'EF-S18-135mm f/3.5-5.6 IS USM', 'With Nano USM motor and IS'),
(21, 'AF-S NIKKOR 500MM.jpg', 'AF-S NIKKOR 500MM F/5.6E PF ED VRNEW', 'Price quoted is MRP inclusive of all taxes for one unit of the product.'),
(22, 'AF-S NIKKOR 180-400MM.jpg', 'AF-S NIKKOR 180-400MM F/4E TC1.4 FL ED VR', 'LC-K103 slip-on Front Lens Cap, LF-4 Rear Lens Cap, HK-41 Lens Hood, Dedicated slip-in Filter Holder*, 40.5 mm screw-on Neutral Color (NC) filter, LN-2 Strap, CL-L2 Lens Case * Dedicated accessories are not available for general purchase. Contact a Nikon-authorized service representative for spares or replacements.'),
(23, 'AF-P NIKKOR 70-300MM.jpg', 'AF-P NIKKOR 70-300MM F/4.5-5.6E ED VR', 'LC-67 67 mm snap-on Front Lens Cap, LF-4 Rear Lens Cap, HB-82 Bayonet Hood, CL-1022 Lens Case'),
(24, 'AF-P DX NIKKOR 10-20MM.jpg', 'AF-P DX NIKKOR 10-20MM F/4.5-5.6G VR', 'LC-72 72 mm snap-on Front Lens Cap, LF-4 Rear Lens Cap, HB-81 Bayonet Hood, CL-1015 Lens Case'),
(25, 'FE 400 mm.jpg', 'FE 400 mm F2.8 GM OSS', 'Premium G Master series large-aperture super telephoto lens\r\nNewly developed XD Linear Motor for extremely fast, precise, quiet AF\r\nThree fluorite lenses for outstanding resolution'),
(26, 'FE 24mm.jpg', 'FE 24mm F1.4 GM', 'Premium G Master Series Wide-range prime lens\r\nDDSSM (Direct Drive SSM) for quiet, highly precise focus lens control\r\nCircular 11-blade aperture for beautiful defocus effects\r\nTwo XA (extreme aspherical) elements in an optical design contribute to G Master high resolution'),
(27, 'E 18-135mm.jpg', 'E 18-135mm F3.5-5.6 OSS', 'APS-C high-magnification standard zoom lens\r\nAdvanced optical design incorporating an aspherical element for high corner-to-corner resolution\r\nAdvanced linear motor technology for fast, precise and quiet focus control'),
(28, 'FUJINON LENS GF45mm.jpg', 'FUJINON LENS GF45mmF2.8 R WR', 'FUJINON GF45mmF2.8 R WR Lens is a highly versatile wide angle lens with a focal length equivalent to 36mm (on a 35mm format) and maximum F2.8 aperture. Thanks to its compact and lightweight design (weighing only 490g), this lens is ideal for street and documentary photography.'),
(29, 'FUJINON LENS GF110mm.jpg', 'FUJINON LENS GF110mmF2 R LM WR', 'GF lenses achieve ultra-high resolution and are capable of supporting further enhancement in future. Utilizing the knowledge cultivated through the development of the XF lenses, GF lenses are Fujifilm finest class of lenses and were designed by amassing various technologies of Fujifilm. They are designed to fully unlock performance potential of the GFX 50S.'),
(30, 'Simpex 888 Tripod.jpg', 'Simpex 888 Tripod ', 'Tripod Weight: 1.8 Kg  Vertical Leg Locks  Geared.\r\nLeg Diameter: 26.8 mm  Leg Brace with Lock  View.'),
(31, 'Simpex 333 Aluminium Standard Tripod White.jpg', 'Simpex 333 Aluminium Standard Tripod ', 'Max Load Capacity Upto 3  Pan Head:3way\r\nSimpex 333 Tripod, Features:Aluminum Oval Section.'),
(32, 'Simpex 1055 Monopod - Black.jpg', 'Simpex 1055 Monopod - Black', 'Product Type : Monopod  Features : Lightweight Str...\r\n\r\nIN THE BOX\r\nSales Package\r\nMain Unit, 1 x Carryin.'),
(33, 'Simpex 552 Black Monopod.jpg', 'Simpex 552 Black Monopod', 'Max Load Capacity (in kg):10  Warranty (in months)\r\n\r\nGeneral\r\nModel Name	552\r\nColor	Black'),
(34, 'Simpex 522 Flash Camera Accessories.jpg', 'Simpex 522 Flash Camera Accessories', 'Product Type : Flash  Features : Power Up: Increament\r\nPower up: increase the power output of the flash.'),
(35, 'Simpex 621RX.jpeg', 'Simpex 621RX', 'Model Name:621RX  Color:Black  Mode:Auto & Manual.\r\nBox Content:Manual, Flash, Remote for Flash, 1 Flash'),
(36, 'Canon Original Battery.jpg', 'Canon LP-E6 Original Battery ', 'Product Type : Battery  Compact and light weighted\r\nCanon Camera EOS 5D Mark II, Battery Part Number.'),
(37, 'Sony NP-FW50 InfoLITHIUM Rechargeable Battery.jpg', 'Sony NP-FW50 InfoLITHIUM Rechargeable Battery', 'Provides Extended Movie/Photo Shooting  57 grams.\r\nSony NP-FW50 InfoLITHIUM Rechargeable Battery'),
(38, 'Nikon Rechargeable battery.jpg', 'Nikon EN-EL 14A Rechargeable Li-ion battery ', 'product Type : Battery Charger\r\nProduct Type : Battery Charger SUPC: SDL907001699'),
(39, 'Nikon MH-24 Camera Battery Charge.jpg', 'Nikon MH-24 Camera Battery Charge', 'Model Name:MH-24  Compatible Battery Type:9V\r\nGeneral\r\nCompatible Battery Type	9V\r\nIn the box.'),
(40, 'Canon LC-E8E Battery Charger (4520B001AA).jpg', 'Canon LC-E8E Battery Charger (4520B001AA)', 'Power Requirements: 110-240VAC 50/60 Hz  Charger ...\r\n\r\nSpecification\r\nBrand	Canon\r\nModel	LC-E8E'),
(41, 'Sony NP-BN1 Camera Battery Charger.jpg', 'Sony NP-BN1 Camera Battery Charger', 'Model Name:NP-BN1  Compatible Battery Type:9V  No ...\r\nCompatible Battery Type 9V\r\nNo of Charging Slots1.'),
(42, 'Digitek Speedlite.jpeg', 'Digitek Speedlite DFL 003 Macro', 'Model Name:Speedlite DFL 003  Type:Macro  Color:Bl...\r\nMode:Manual  Recycling Time:0.1 - 5 s'),
(43, 'Sonia Porta Light.jpg', 'Sonia Porta Light ', 'Product Type : Flashlights\r\nBad lighting will not spoil your pictures anymore ..'),
(44, 'Digitek LED Light 204C.jpg', 'Digitek LED Light 204C', 'Model Name:LED Light 204C  Color:Black  Mode:Manua...\r\nDigitek led video light LED-D204C'),
(45, 'Canon EF-S 18-55.webp', 'Canon EF-S 18-55&55-250 IS II&STM LENS UV', 'Model Name:EF-S 18-55 AND 55-250 IS II AND STM LE...\r\n58Mm UV Filter For EF-S 18-55 IS II , STM , EF-S 5...'),
(46, 'DigiTek 67 MM UV Filter (Black).jpg', 'DigiTek 67 MM UV Filter (Black)', 'Product Type : Filters\r\nNoted for offering you maximum light transmission ...'),
(47, 'Digitek Digitek  Simpex Mini Flash Bouncer.jpg', 'Digitek Mini Flash Bouncer', 'Model Name:Digitek / Simpex Mini Flash Bouncer  Co...\r\nDigitek / Simpex Flash Mini Bouncer'),
(48, 'Sonia Flash Diffuser Lambency Diffuser.jpg', 'Sonia Flash Diffuser', 'roduct Type : Flash Diffuser\r\nContents Sonia Lambency Diffuser - 1 no Dome - 4 n'),
(49, 'Sonia Monopod.jpg', 'Sonia Monopod Pro-111 ', 'Product Type : Monopod\r\nBrand	Sonia\r\nModel	Pro111-3L-BH\r\nType	Monopod'),
(50, 'Sonia Ph 660 Tripod (Load Capacity 3000 g).jpg', 'Sonia Ph 660 Tripod ', 'High Grade Aluminium Body  3-Way Pan Head  Quick ...\r\nPopular brand Sonia brings to you this utilitarian...'),
(51, 'Scratchgard Screen Protector for Nikon D3300.jpg', 'Scratchgard Screen Protector ', 'Compatible DSLR Models:Nikon D3300  Other Features...\r\nProtect your Camera display against scratches and ...'),
(52, 'SHOPEE Nikon EyeCup.jpg', 'Nikon DK-21 EyeCup Eyepiece', 'Model:Nikon DK-21 DK 21 EyeCup Eyepiece replacemen...\r\nReplacement for your Lost Eyepiece Suitable For.'),
(53, 'Nikon Shoulder Camera Bag (Black).jpg', 'Nikon Shoulder Camera Bag (Black)', 'No. of Compartments:3  Bottle Pocket:Yes  Features...\r\nA photographer ideal friend a photographer mos.'),
(54, 'Canon 200D Camera Bag (Black).jpg', 'Canon 200D Camera Bag (Black)', 'Ideal for DSLR/SLR Cameras  Adjustable Shoulder St...\r\nIf you are looking for a DSLR camera bag which is ...'),
(55, 'Camera Tripod Backpack Bag.jpg', 'Camera Tripod Backpack Bag ', 'Specification: Color: Black + Dark Blue Material.\r\nFeatures: Brand New and high quality.'),
(56, 'R.png', 'EOS R (RF24-105mm f/4L IS USM)', 'EOS R (RF24-105mm f/4L IS USM)'),
(57, 'lense.png', 'EF70-200mm f/2.8L IS III USM', 'EF70-200mm f/2.8L IS III USM'),
(58, 'potra.jpg', 'Sonia Potra Light for Video and Continuous Lightin', 'Sonia Potra Light for Video and Continuous Lighting'),
(59, 'R.png', 'EOS R (RF24-105mm f/4L IS USM)', 'EOS R (RF24-105mm f/4L IS USM)');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `slider_id` int(4) NOT NULL,
  `title` varchar(50) NOT NULL,
  `sub_title` varchar(100) NOT NULL,
  `media_id` int(4) NOT NULL,
  `btn_text` varchar(50) NOT NULL,
  `btn_url` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`slider_id`, `title`, `sub_title`, `media_id`, `btn_text`, `btn_url`) VALUES
(1, 'EOS R', '(RF24-105mm f/4L IS USM)', 56, 'View More', 'www.google.com'),
(2, 'EF70-200mm', 'f/2.8L IS III USM', 57, 'View More', 'www.google.com'),
(3, 'Sonia Potra Light', 'for Video and Continuous Lighting', 58, 'View More', 'www.google.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accessories`
--
ALTER TABLE `accessories`
  ADD PRIMARY KEY (`Acc_id`);

--
-- Indexes for table `accessoriesmaster`
--
ALTER TABLE `accessoriesmaster`
  ADD PRIMARY KEY (`Acc_cat_id`);

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `camera`
--
ALTER TABLE `camera`
  ADD PRIMARY KEY (`cam_id`) USING BTREE;

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`cust_id`);

--
-- Indexes for table `lenses`
--
ALTER TABLE `lenses`
  ADD PRIMARY KEY (`lense_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`media_id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`slider_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accessories`
--
ALTER TABLE `accessories`
  MODIFY `Acc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `accessoriesmaster`
--
ALTER TABLE `accessoriesmaster`
  MODIFY `Acc_cat_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `camera`
--
ALTER TABLE `camera`
  MODIFY `cam_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cat_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `cust_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lenses`
--
ALTER TABLE `lenses`
  MODIFY `lense_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `media_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `slider_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
